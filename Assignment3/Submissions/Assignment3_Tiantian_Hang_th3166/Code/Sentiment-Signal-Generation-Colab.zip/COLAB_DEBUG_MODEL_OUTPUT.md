# 在 Colab 中检查模型是否正确生成输出

## 快速开始

### 方法 1: 使用 Colab 调试脚本（推荐）

1. **上传并解压 ZIP 文件到 Colab**

```python
from google.colab import files
uploaded = files.upload()  # 上传 Sentiment-Signal-Generation-Colab.zip

!unzip -q Sentiment-Signal-Generation-Colab.zip -d /content/
```

2. **设置环境变量**

```python
import os
os.environ['HF_TOKEN'] = 'your_huggingface_token_here'
os.environ['FINNHUB_API_KEY'] = 'your_finnhub_key_here'  # 可选
```

3. **运行调试脚本**

```python
# 基本用法（使用默认值：AAPL, 2024-12-01）
!cd /content && python debug_model_output_colab.py

# 指定股票代码和日期
!cd /content && python debug_model_output_colab.py NBR 2024-12-01

# 完整参数（股票代码、日期、回溯周数）
!cd /content && python debug_model_output_colab.py AAPL 2024-12-01 3
```

### 方法 2: 在 Colab Notebook 中直接运行

```python
# 在 Colab Notebook 的单元格中运行

import os
import sys

# 设置环境变量
os.environ['HF_TOKEN'] = 'your_huggingface_token_here'

# 添加路径
sys.path.insert(0, '/content')

# 导入模块
from signal_generator.sentiment_agent import SentimentAgent
from news_fetcher.data_fetcher import NewsDataFetcher
from news_fetcher.prompt_builder import PromptBuilder

# 初始化
print("初始化 SentimentAgent...")
agent = SentimentAgent()
print(f"设备: {agent.device}")

# 获取新闻数据
print("获取新闻数据...")
fetcher = NewsDataFetcher()
news_data = fetcher.fetch_all_data("AAPL", "2024-12-01", n_weeks=3)
print(f"获取到 {len(news_data)} 条新闻")

# 构建 Prompt
print("构建 Prompt...")
prompt_builder = PromptBuilder()
info, prompt = prompt_builder.get_all_prompts_online(
    "AAPL", news_data, "2024-12-01", with_basics=True
)

# 格式化 prompt
formatted_prompt = (
    agent.B_INST + agent.B_SYS + 
    agent.SYSTEM_PROMPT + agent.E_SYS + 
    prompt + agent.E_INST
)

print(f"Prompt 长度: {len(formatted_prompt)} 字符")

# Tokenize
print("Tokenize 输入...")
inputs = agent.tokenizer(formatted_prompt, return_tensors='pt')
inputs = {key: value.to(agent.device) for key, value in inputs.items()}
print(f"输入 token 数量: {inputs['input_ids'].shape[1]}")

# 生成输出
print("生成模型输出（这可能需要几分钟）...")
import torch
with torch.no_grad():
    res = agent.model.generate(
        **inputs,
        max_length=4096,
        do_sample=True,
        eos_token_id=agent.tokenizer.eos_token_id,
        use_cache=True,
        temperature=0.7,
        top_p=0.9
    )

# 解码输出
output = agent.tokenizer.decode(res[0], skip_special_tokens=True)

# 关键检查：输出长度是否大于 prompt 长度
print(f"\n{'='*80}")
print("关键检查结果")
print(f"{'='*80}")
print(f"Prompt 长度: {len(formatted_prompt)} 字符")
print(f"输出总长度: {len(output)} 字符")
print(f"模型生成部分: {len(output) - len(formatted_prompt)} 字符")
print(f"新生成 token 数量: {res[0].shape[0] - inputs['input_ids'].shape[1]}")

if len(output) > len(formatted_prompt):
    print("\n✅ 模型生成了新内容！")
    model_generated = output[len(formatted_prompt):].strip()
    print(f"前 300 字符:")
    print(model_generated[:300])
else:
    print("\n❌ 警告: 模型没有生成新内容！")
    print("输出可能只包含 prompt")

# 解析输出
result = agent._parse_output(output, "AAPL")
print(f"\n解析结果:")
print(f"  Signal: {result['signal']}")
print(f"  Confidence: {result['confidence']}")
print(f"  Predicted Return: {result['predicted_return']}")
```

## 关键检查点

### 1. 检查输出长度是否大于 prompt 长度（最重要）

```python
if len(output) > len(formatted_prompt):
    print("✅ 模型生成了新内容")
    model_generated = output[len(formatted_prompt):].strip()
    print(f"生成的内容长度: {len(model_generated)} 字符")
else:
    print("❌ 模型没有生成新内容")
```

### 2. 检查新生成的 token 数量

```python
new_tokens = res[0].shape[0] - inputs['input_ids'].shape[1]
if new_tokens > 0:
    print(f"✅ 模型生成了 {new_tokens} 个新 token")
else:
    print("❌ 模型没有生成新 token")
```

### 3. 检查是否包含 Prediction

```python
import re
prediction_match = re.search(
    r'Prediction:\s*(?:up|down)\s*(?:by)?\s*([\d.]+)%',
    output,
    re.IGNORECASE
)

if prediction_match:
    print(f"✅ 找到 Prediction: {prediction_match.group(0)}")
else:
    print("⚠️  没有找到 Prediction 模式")
```

## 预期输出

### 正常情况

```
================================================================================
模型输出调试工具 (Colab)
================================================================================
股票代码: AAPL
日期: 2024-12-01
回溯周数: 3
================================================================================

[1/7] 初始化 SentimentAgent...
  ✓ SentimentAgent 初始化成功
  - 设备: cuda
  - 模型类型: LlamaForCausalLM

[2/7] 获取新闻数据...
  ✓ 获取到 15 条新闻

[3/7] 构建 Prompt...
  ✓ Prompt 构建成功
  - Prompt 长度: 2500 字符

[4/7] Tokenize 输入...
  ✓ 输入 tokenize 成功
  - 输入设备: cuda
  - 输入 token 数量: 650

[5/7] 生成模型输出...
  ✓ 模型生成完成
  - 输出 token 数量: 850
  - 输入 token 数量: 650
  - 新生成 token 数量: 200
  ✅ 模型生成了新内容！

[6/7] 解码和解析输出...
  ✓ 输出解码成功
  - 输出总长度: 3200 字符
  - 输入 prompt 长度: 2500 字符
  - 模型生成部分长度: 700 字符

  ✅ 模型生成了新内容 (700 字符)

[7/7] 解析输出...
  ✓ 输出解析完成
  - Signal: 1 (BUY)
  - Confidence: 0.75
  - Predicted Return: 0.0350 (3.50%)

  ✅ 找到 Prediction 模式
  - 匹配内容: Prediction: up by 3.5%

================================================================================
调试总结
================================================================================

✅ 没有发现明显问题
  模型似乎正常工作！
================================================================================
```

### 异常情况（模型没有生成新内容）

```
[5/7] 生成模型输出...
  ✓ 模型生成完成
  - 输出 token 数量: 650
  - 输入 token 数量: 650
  - 新生成 token 数量: 0
  ❌ 警告: 模型没有生成新内容！

[6/7] 解码和解析输出...
  ❌ 警告: 模型没有生成新内容！
  - 输出长度: 2500
  - Prompt 长度: 2500

================================================================================
调试总结
================================================================================

发现的问题:
  ❌ 模型没有生成新内容（输出长度 <= prompt 长度）
  ❌ 模型没有生成新 token（新生成 token 数量 <= 0）
  ⚠️  使用了默认值（signal=0, confidence=0.5）
```

## 常见问题诊断

### 问题 1: 输出长度 = Prompt 长度

**原因：**
- 模型没有生成新内容
- `max_length` 设置太小
- 模型生成立即遇到 EOS token

**解决方案：**
- 检查 `max_length` 是否足够大（建议 >= 输入长度 + 500）
- 检查模型是否正确加载
- 检查设备是否正确（CPU vs GPU）

### 问题 2: 新生成 token 数量 = 0

**原因：**
- 模型没有生成新内容
- 生成参数设置不正确

**解决方案：**
- 检查 `do_sample=True` 是否设置
- 检查 `eos_token_id` 是否正确
- 检查 `temperature` 和 `top_p` 参数

### 问题 3: 找不到 Prediction 模式

**原因：**
- 模型输出格式不符合预期
- 正则表达式不匹配

**解决方案：**
- 查看完整的 `raw_output`（保存在 `debug_output_{symbol}_{date}.txt`）
- 检查模型实际输出格式
- 调整 `_parse_output` 中的正则表达式

## 调试检查清单

运行调试脚本后，检查以下项目：

- [ ] ✅ SentimentAgent 成功初始化
- [ ] ✅ 模型正确加载（没有错误信息）
- [ ] ✅ 设备正确（GPU 或 CPU）
- [ ] ✅ 成功获取新闻数据
- [ ] ✅ Prompt 正确构建
- [ ] ✅ 输入正确 tokenize
- [ ] ✅ **模型生成新内容（输出长度 > prompt 长度）** ← 最重要
- [ ] ✅ **新生成 token 数量 > 0** ← 最重要
- [ ] ✅ 输出包含 "Prediction" 关键词
- [ ] ✅ 输出解析成功（predicted_return 不为 0 或 signal 不为 0）
- [ ] ✅ `raw_output` 包含完整的模型输出（不只是 prompt）

## 保存的调试文件

调试脚本会生成 `debug_output_{symbol}_{date}.txt` 文件，包含：
- 完整的输入 prompt
- 完整的模型输出（包含 prompt）
- 模型生成的部分（不包含 prompt）

可以下载这个文件来详细分析：

```python
from google.colab import files
files.download('debug_output_AAPL_2024-12-01.txt')
```

## 下一步

如果调试脚本发现问题：

1. **模型没有生成新内容**：
   - 检查模型是否正确加载
   - 检查设备是否正确
   - 检查 `max_length` 参数

2. **找不到 Prediction 模式**：
   - 查看完整的 `raw_output`
   - 调整解析逻辑

3. **所有 Signal 都是 0**：
   - 检查 `predicted_return` 的值
   - 如果预测收益率在 ±2% 范围内，这是正常的

