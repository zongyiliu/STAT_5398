# 使用本地价格数据更新说明

## 📊 修改概述

已修改代码，使其**优先使用本地 `sp500_tickers_daily_price.csv` 文件**获取 close price，而不是通过 yfinance API。

---

## 🔧 修改内容

### 1. `news_fetcher/data_fetcher.py`

#### 修改 `__init__` 方法
- 添加 `price_data_path` 参数
- 如果提供了价格文件路径，预加载价格数据到内存
- 构建 `gvkey → ticker` 映射

#### 修改 `get_stock_data` 方法
- 拆分为两个方法：
  - `_get_stock_data_from_local()`: 从本地文件读取
  - `_get_stock_data_from_api()`: 从 yfinance API 读取（原方法）
- 优先使用本地数据，如果失败则回退到 API

### 2. `generate_sentiment_signals.py`

#### 修改 `main` 函数
- 在创建 `NewsDataFetcher` 实例时，传递 `price_file` 参数

---

## ✅ 优势

1. **更快**: 不需要网络请求，直接从内存读取
2. **更稳定**: 不依赖网络连接和 yfinance API
3. **离线可用**: 不需要互联网连接
4. **数据一致**: 使用与回测相同的数据源，保证一致性

---

## 🔄 工作流程

```
1. 初始化 NewsDataFetcher
   └── 如果提供了 price_data_path:
       ├── 加载 sp500_tickers_daily_price.csv
       ├── 提取 gvkey, tic, datadate, prccd 列
       └── 构建 gvkey → ticker 映射

2. 调用 get_stock_data(ticker, steps)
   └── 如果本地数据已加载:
       ├── 通过 ticker 找到 gvkey
       ├── 从本地数据中筛选该 gvkey 的价格数据
       ├── 根据 steps 日期范围筛选数据
       └── 返回 Start Date, End Date, Start Price, End Price
   └── 如果本地数据未加载或失败:
       └── 回退到 yfinance API（原方法）

3. 自动回退机制
   └── 如果以下情况发生，自动使用 API:
       ├── 价格文件路径未提供
       ├── 价格文件加载失败
       ├── ticker 在本地数据中不存在
       ├── 日期范围内没有数据
       └── 数据不足（少于2个日期）
```

---

## 📋 使用方法

### 命令行使用

```bash
python generate_sentiment_signals.py \
    --stock_selected_file /content/stock_selected.csv \
    --price_file /content/sp500_tickers_daily_price.csv \
    --output_file sentiment_signals.csv
```

### 代码中使用

```python
from news_fetcher.data_fetcher import NewsDataFetcher

# 使用本地价格数据
news_fetcher = NewsDataFetcher(
    price_data_path='/content/sp500_tickers_daily_price.csv'
)

# 或者不使用本地数据（使用 API）
news_fetcher = NewsDataFetcher()
```

---

## ⚠️ 注意事项

1. **文件格式要求**
   - `sp500_tickers_daily_price.csv` 必须包含以下列：
     - `gvkey`: 股票唯一标识符
     - `tic`: 股票代码（ticker）
     - `datadate`: 交易日期
     - `prccd`: 收盘价（close price）

2. **内存使用**
   - 预加载价格数据会占用内存（约 269MB 文件）
   - 如果内存有限，可以不提供 `price_data_path`，使用 API

3. **数据完整性**
   - 如果本地数据不完整（缺少某些 ticker 或日期），会自动回退到 API
   - 建议确保本地数据包含所需的所有 ticker 和日期范围

4. **向后兼容**
   - 如果不提供 `price_data_path`，行为与之前完全一致（使用 API）
   - 现有代码无需修改即可继续工作

---

## 🧪 测试建议

1. **测试本地数据加载**
   ```python
   news_fetcher = NewsDataFetcher(price_data_path='sp500_tickers_daily_price.csv')
   # 应该看到: "Loaded X price records for Y stocks"
   ```

2. **测试价格获取**
   ```python
   steps = ['2024-12-01', '2024-12-08', '2024-12-15']
   data = news_fetcher.get_stock_data('AAPL', steps)
   print(data)
   ```

3. **测试回退机制**
   - 使用不存在的 ticker，应该自动回退到 API
   - 使用超出日期范围的数据，应该自动回退到 API

---

## 📝 修改文件清单

- ✅ `news_fetcher/data_fetcher.py`
  - 修改 `__init__` 方法
  - 修改 `get_stock_data` 方法
  - 新增 `_get_stock_data_from_local` 方法
  - 重构 `_get_stock_data_from_api` 方法

- ✅ `generate_sentiment_signals.py`
  - 修改 `main` 函数中创建 `NewsDataFetcher` 的部分

---

## 🎯 总结

现在代码会：
1. **优先使用本地数据**（如果提供了价格文件路径）
2. **自动回退到 API**（如果本地数据不可用）
3. **保持向后兼容**（不提供路径时使用 API）

这样既提高了性能，又保持了灵活性！

