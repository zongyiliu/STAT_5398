# Colab 快速开始指南

## 🚀 快速运行（文件在 /content/ 目录）

如果您的文件已经上传到 Colab 的 `/content/` 目录：

```python
# 运行生成情感信号
!python generate_sentiment_signals.py \
    --stock_selected_file "/content/stock_selected.csv" \
    --price_file "/content/sp500_tickers_daily_price.csv" \
    --output_file "sentiment_signals.csv"
```

## 📋 完整步骤

### 步骤 1: 上传文件到 Colab

```python
from google.colab import files

# 上传 stock_selected.csv
print("请上传 stock_selected.csv")
uploaded = files.upload()
for filename in uploaded.keys():
    if 'stock_selected' in filename:
        print(f"✓ {filename} 已上传")

# 上传 sp500_tickers_daily_price.csv
print("\n请上传 sp500_tickers_daily_price.csv")
uploaded = files.upload()
for filename in uploaded.keys():
    if 'sp500_tickers_daily_price' in filename:
        print(f"✓ {filename} 已上传")
```

**注意**: 上传的文件会自动保存到 `/content/` 目录。

### 步骤 2: 运行生成脚本

```python
!python generate_sentiment_signals.py \
    --stock_selected_file "/content/stock_selected.csv" \
    --price_file "/content/sp500_tickers_daily_price.csv" \
    --output_file "sentiment_signals.csv" \
    --save_to_drive
```

### 步骤 3: 下载结果

```python
from google.colab import files
files.download('sentiment_signals.csv')
```

---

## 🔧 自动检测功能

代码现在支持自动检测文件位置！如果文件在常见位置，可以省略参数：

```python
# 自动检测模式（文件在 /content/ 目录）
!python generate_sentiment_signals.py
```

代码会自动查找：
- `stock_selected.csv`: `/content/stock_selected.csv`, `stock_selected.csv`, `data_processor/outputs/stock_selected.csv`
- `price_file`: `/content/sp500_tickers_daily_price.csv`, `sp500_tickers_daily_price.csv`, `../dec data/sp500_tickers_daily_price.csv`

---

## 📝 参数说明

| 参数 | 说明 | 示例 |
|------|------|------|
| `--stock_selected_file` | stock_selected.csv 的完整路径 | `/content/stock_selected.csv` |
| `--price_file` | 价格数据文件的完整路径 | `/content/sp500_tickers_daily_price.csv` |
| `--output_file` | 输出文件路径（可选） | `sentiment_signals.csv` |
| `--save_to_drive` | 自动保存到 Google Drive | 无值 |
| `--max_stocks` | 限制股票数量（测试用） | `5` |
| `--start_date` | 开始日期 | `2024-12-01` |
| `--end_date` | 结束日期 | `2024-12-31` |

---

## 💡 推荐用法

### 最简单的方式（自动检测）

```python
# 确保文件在 /content/ 目录
!python generate_sentiment_signals.py
```

### 明确指定路径（推荐）

```python
!python generate_sentiment_signals.py \
    --stock_selected_file "/content/stock_selected.csv" \
    --price_file "/content/sp500_tickers_daily_price.csv"
```

### 测试模式（5只股票）

```python
!python generate_sentiment_signals.py \
    --stock_selected_file "/content/stock_selected.csv" \
    --price_file "/content/sp500_tickers_daily_price.csv" \
    --max_stocks 5 \
    --start_date "2024-12-01" \
    --end_date "2024-12-31"
```

---

## ⚠️ 常见问题

### 问题 1: 文件未找到

**错误**: `FileNotFoundError: stock_selected.csv not found`

**解决**: 
1. 检查文件是否在 `/content/` 目录
2. 使用 `--stock_selected_file` 明确指定路径
3. 运行 `!ls /content/` 查看文件列表

### 问题 2: 路径错误

**解决**: 使用绝对路径：
```python
--stock_selected_file "/content/stock_selected.csv"
```

### 问题 3: 文件上传位置

**说明**: 使用 `files.upload()` 上传的文件会自动保存到 `/content/` 目录。

---

## 📊 完整示例

```python
# ============================================================================
# Colab 完整运行示例
# ============================================================================

# 1. 安装依赖
!pip install -q pandas numpy tqdm python-dotenv finnhub-python yfinance transformers peft torch

# 2. 上传项目文件（如果还没有）
from google.colab import files
import zipfile

uploaded = files.upload()
for filename in uploaded.keys():
    if filename.endswith('.zip'):
        with zipfile.ZipFile(filename, 'r') as zip_ref:
            zip_ref.extractall('.')

# 3. 上传数据文件
print("上传 stock_selected.csv")
uploaded = files.upload()

print("上传 sp500_tickers_daily_price.csv")
uploaded = files.upload()

# 4. 设置 API Keys
import os
os.environ['FINNHUB_API_KEY'] = 'your_key'
os.environ['HF_TOKEN'] = 'your_token'

# 5. 运行生成
!python generate_sentiment_signals.py \
    --stock_selected_file "/content/stock_selected.csv" \
    --price_file "/content/sp500_tickers_daily_price.csv" \
    --output_file "sentiment_signals.csv" \
    --save_to_drive

# 6. 下载结果
files.download('sentiment_signals.csv')
```

---

## ✅ 验证文件位置

运行前可以验证文件是否存在：

```python
import os

# 检查文件
files_to_check = [
    '/content/stock_selected.csv',
    '/content/sp500_tickers_daily_price.csv',
]

for file_path in files_to_check:
    if os.path.exists(file_path):
        size = os.path.getsize(file_path) / 1024 / 1024
        print(f"✓ {file_path} ({size:.2f} MB)")
    else:
        print(f"✗ {file_path} (not found)")
```

---

## 🎯 总结

**最简单的运行方式**:

```python
# 文件在 /content/ 目录时
!python generate_sentiment_signals.py \
    --stock_selected_file "/content/stock_selected.csv" \
    --price_file "/content/sp500_tickers_daily_price.csv"
```

代码已更新，支持自动检测和灵活路径配置！

