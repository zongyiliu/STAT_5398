# Colab 情感信号生成指南

## 📦 打包文件说明

**打包文件**: `Sentiment-Signal-Generation-Colab.zip`

**包含内容**:
- ✅ `generate_sentiment_signals.py` - 主脚本
- ✅ `news_fetcher/` - 新闻获取模块
- ✅ `signal_generator/` - 信号生成模块（包含 SentimentAgent）
- ✅ `requirements.txt` - 依赖列表
- ✅ `colab_setup.py` - Colab 环境设置脚本
- ✅ `.env.example` - 环境变量模板
- ✅ 相关文档

**不包含**:
- ❌ 大型数据文件（需要单独上传）
- ❌ 结果文件
- ❌ 测试文件

---

## 🚀 在 Colab 上运行步骤

### 步骤 1: 上传并解压文件

```python
# 在 Colab 中运行
from google.colab import files
import zipfile
import os

# 上传 ZIP 文件
print("请上传 Sentiment-Signal-Generation-Colab.zip")
uploaded = files.upload()

# 解压文件
for filename in uploaded.keys():
    if filename.endswith('.zip'):
        print(f"解压 {filename}...")
        with zipfile.ZipFile(filename, 'r') as zip_ref:
            zip_ref.extractall('.')
        print("✓ 解压完成")
```

### 步骤 2: 安装依赖

```python
# 运行设置脚本（自动安装依赖）
!python colab_setup.py

# 或手动安装
!pip install -q pandas numpy tqdm python-dotenv finnhub-python yfinance transformers peft torch
```

### 步骤 3: 设置 API Keys

```python
import os

# 设置您的 API keys
os.environ['FINNHUB_API_KEY'] = 'your_finnhub_api_key_here'
os.environ['HF_TOKEN'] = 'your_huggingface_token_here'

# 验证设置
print("✓ API Keys 已设置")
print(f"  FINNHUB_API_KEY: {'已设置' if os.environ.get('FINNHUB_API_KEY') else '未设置'}")
print(f"  HF_TOKEN: {'已设置' if os.environ.get('HF_TOKEN') else '未设置'}")
```

### 步骤 4: 上传数据文件

```python
from google.colab import files
import os

# 创建必要的目录
os.makedirs('data_processor/outputs', exist_ok=True)
os.makedirs('dec data', exist_ok=True)

# 上传 stock_selected.csv
print("请上传 stock_selected.csv 到 data_processor/outputs/")
uploaded = files.upload()
for filename in uploaded.keys():
    if 'stock_selected' in filename:
        os.rename(filename, f'data_processor/outputs/stock_selected.csv')
        print(f"✓ {filename} 已移动到 data_processor/outputs/")

# 上传价格数据文件（用于 gvkey 映射）
print("\n请上传 sp500_tickers_daily_price.csv 到 dec data/")
uploaded = files.upload()
for filename in uploaded.keys():
    if 'sp500_tickers_daily_price' in filename:
        os.rename(filename, f'dec data/sp500_tickers_daily_price.csv')
        print(f"✓ {filename} 已移动到 dec data/")
```

**或者使用 Google Drive**:

```python
from google.colab import drive
import shutil

# 挂载 Google Drive
drive.mount('/content/drive')

# 复制文件
shutil.copy('/content/drive/MyDrive/path/to/stock_selected.csv', 
            'data_processor/outputs/stock_selected.csv')
shutil.copy('/content/drive/MyDrive/path/to/sp500_tickers_daily_price.csv', 
            'dec data/sp500_tickers_daily_price.csv')
```

### 步骤 5: 启用 GPU

```python
# 检查 GPU 是否可用
import torch
print(f"CUDA 可用: {torch.cuda.is_available()}")
if torch.cuda.is_available():
    print(f"GPU 设备: {torch.cuda.get_device_name(0)}")
    print(f"GPU 内存: {torch.cuda.get_device_properties(0).total_memory / 1024**3:.2f} GB")
else:
    print("⚠️  警告: 未检测到 GPU，请确保在 Colab 中启用了 GPU")
    print("   Runtime → Change runtime type → GPU (A100 推荐)")
```

### 步骤 6: 运行测试（小规模）

```python
# 测试模式：5只股票，1个月数据
!python generate_sentiment_signals.py \
    --max_stocks 5 \
    --start_date "2024-12-01" \
    --end_date "2024-12-31" \
    --data_dir "data_processor/outputs" \
    --price_file "dec data/sp500_tickers_daily_price.csv" \
    --output_file "data_processor/outputs/sentiment_signals.csv"
```

### 步骤 7: 运行完整生成

```python
# 完整运行（所有股票，所有日期）
!python generate_sentiment_signals.py \
    --data_dir "data_processor/outputs" \
    --price_file "dec data/sp500_tickers_daily_price.csv" \
    --output_file "data_processor/outputs/sentiment_signals.csv"
```

---

## 📋 完整 Colab Notebook 模板

```python
# ============================================================================
# Dual-Insight Trader - 情感信号生成 (Colab)
# ============================================================================

# 1. 安装依赖
!pip install -q pandas numpy tqdm python-dotenv finnhub-python yfinance transformers peft torch

# 2. 上传并解压代码
from google.colab import files
import zipfile
import os

print("请上传 Sentiment-Signal-Generation-Colab.zip")
uploaded = files.upload()
for filename in uploaded.keys():
    if filename.endswith('.zip'):
        with zipfile.ZipFile(filename, 'r') as zip_ref:
            zip_ref.extractall('.')
        print("✓ 解压完成")

# 3. 设置 API Keys
import os
os.environ['FINNHUB_API_KEY'] = 'your_key_here'
os.environ['HF_TOKEN'] = 'your_token_here'

# 4. 上传数据文件
os.makedirs('data_processor/outputs', exist_ok=True)
os.makedirs('dec data', exist_ok=True)

print("请上传 stock_selected.csv")
uploaded = files.upload()
for filename in uploaded.keys():
    if 'stock_selected' in filename:
        os.rename(filename, 'data_processor/outputs/stock_selected.csv')

print("请上传 sp500_tickers_daily_price.csv")
uploaded = files.upload()
for filename in uploaded.keys():
    if 'sp500_tickers_daily_price' in filename:
        os.rename(filename, 'dec data/sp500_tickers_daily_price.csv')

# 5. 检查 GPU
import torch
print(f"GPU 可用: {torch.cuda.is_available()}")
if torch.cuda.is_available():
    print(f"GPU: {torch.cuda.get_device_name(0)}")

# 6. 运行测试
!python generate_sentiment_signals.py \
    --max_stocks 5 \
    --start_date "2024-12-01" \
    --end_date "2024-12-31"

# 7. 下载结果
from google.colab import files
files.download('data_processor/outputs/sentiment_signals.csv')
```

---

## ⚙️ 参数说明

### `generate_sentiment_signals.py` 参数

| 参数 | 说明 | 默认值 |
|------|------|--------|
| `--data_dir` | stock_selected.csv 所在目录 | `data_processor/outputs` |
| `--price_file` | 价格数据文件路径 | `../dec data/sp500_tickers_daily_price.csv` |
| `--output_file` | 输出文件路径 | `data_processor/outputs/sentiment_signals.csv` |
| `--start_date` | 开始日期 (YYYY-MM-DD) | 无（全部） |
| `--end_date` | 结束日期 (YYYY-MM-DD) | 无（全部） |
| `--max_stocks` | 最大股票数（测试用） | 无（全部） |
| `--no_resume` | 不续传（重新生成） | False |

---

## 📊 预期时间

| 数据规模 | 时间（A100 GPU） |
|---------|----------------|
| 5只股票，1个月 | 5-10分钟 |
| 50只股票，3个月 | 30-60分钟 |
| 完整数据（19,602条） | 10-15小时 |

---

## ⚠️ 注意事项

### 1. GPU 必需
- 确保在 Colab 中启用 GPU
- Runtime → Change runtime type → GPU
- 推荐使用 A100（Pro 版本）

### 2. API 限制
- **Finnhub**: 60 calls/minute
- 脚本会自动处理速率限制
- 如果超限，会自动等待

### 3. 会话限制
- **免费版**: 每次会话最多12小时
- **建议**: 使用 `--resume` 选项支持断点续传
- 分批处理，保存中间结果

### 4. 数据文件
- `stock_selected.csv` 必须存在
- 价格数据文件用于 gvkey 映射
- 建议使用 Google Drive 存储大文件

### 5. 模型下载
- 首次运行需要下载 FinGPT 模型（约10-20分钟）
- 模型会缓存在 Colab 环境中
- 后续运行只需加载（2-5分钟）

---

## 🔧 故障排除

### 问题 1: GPU 不可用
```python
# 检查 GPU
import torch
print(torch.cuda.is_available())

# 如果返回 False，请：
# 1. Runtime → Change runtime type → GPU
# 2. 重新运行检查
```

### 问题 2: API Key 错误
```python
# 检查 API keys
import os
print(f"FINNHUB_API_KEY: {os.environ.get('FINNHUB_API_KEY', '未设置')[:10]}...")
print(f"HF_TOKEN: {os.environ.get('HF_TOKEN', '未设置')[:10]}...")
```

### 问题 3: 文件未找到
```python
# 检查文件是否存在
import os
print(f"stock_selected.csv: {os.path.exists('data_processor/outputs/stock_selected.csv')}")
print(f"price_file: {os.path.exists('dec data/sp500_tickers_daily_price.csv')}")
```

### 问题 4: 内存不足
- 减少 `--max_stocks` 数量
- 使用更短的日期范围
- 确保使用 A100 GPU（40GB 显存）

---

## 📥 下载结果

### 方法 1: 直接下载（推荐，适用于小文件）

```python
from google.colab import files

# 下载生成的情感信号文件
files.download('data_processor/outputs/sentiment_signals.csv')
```

**注意**: 
- 文件会下载到浏览器的默认下载目录
- 建议文件大小 <100MB
- 大文件请使用方法 2

### 方法 2: 保存到 Google Drive（推荐，适用于大文件或需要保留）

```python
from google.colab import drive
import shutil

# 挂载 Google Drive
drive.mount('/content/drive')

# 保存到 Drive
shutil.copy(
    'data_processor/outputs/sentiment_signals.csv',
    '/content/drive/MyDrive/sentiment_signals.csv'
)

print("✓ 文件已保存到 Google Drive")
print("从浏览器访问 https://drive.google.com 下载")
```

**详细说明**: 请参考 `COLAB_DOWNLOAD_GUIDE.md`

---

## 🔄 断点续传

如果运行中断，可以继续：

```python
# 继续之前的运行（自动跳过已处理的记录）
!python generate_sentiment_signals.py \
    --data_dir "data_processor/outputs" \
    --price_file "dec data/sp500_tickers_daily_price.csv"
    # 默认启用 --resume
```

---

## 📈 下一步

生成 `sentiment_signals.csv` 后：

1. **下载结果文件**
2. **在本地运行 `fuse_signals.py`** 融合信号
3. **优化权重组合**
4. **运行最终回测**

---

## 💡 提示

1. **先测试**: 使用 `--max_stocks 5` 先测试
2. **分批处理**: 使用日期范围分批处理
3. **保存结果**: 定期下载中间结果
4. **监控进度**: 查看进度条了解处理状态

---

## 📚 相关文档

- `GENERATE_SENTIMENT_SIGNALS_LOGIC.md` - 详细逻辑说明
- `SENTIMENT_SIGNAL_GENERATION.md` - 使用指南
- `API_KEYS_SETUP.md` - API keys 设置

