# 为什么 Sentiment Signal 分析需要使用 Close 价格？

## 📊 核心原因

Close 价格数据在 sentiment signal 生成中起到**提供历史上下文**的作用，帮助 LLM 理解**新闻与价格变化的关系**。

---

## 🔍 具体用途

### 1. 构建历史价格-新闻对应关系

在 `prompt_builder.py` 的 `get_prompt_by_row` 方法中，Close 价格用于构建这样的 prompt：

```python
head = (
    f"From {start_date} to {end_date}, {symbol}'s stock price {term} "
    f"from {row['Start Price']:.2f} to {row['End Price']:.2f}. "
    f"Company news during this period are listed below:\n\n"
)
```

**生成的示例**:
```
From 2024-11-10 to 2024-11-17, AAPL's stock price increased from 150.00 to 155.00. 
Company news during this period are listed below:

[Headline]: Apple Reports Record Q4 Earnings
[Summary]: Apple Inc. announced record-breaking quarterly earnings...
```

---

## 🎯 为什么需要这个信息？

### 原因 1: 让 LLM 学习新闻-价格关联模式

**FinGPT 的核心思想**：
- 通过展示**历史数据**（过去几周的价格变化 + 对应新闻），让 LLM 学习：
  - 哪些新闻类型通常导致价格上涨？
  - 哪些新闻类型通常导致价格下跌？
  - 价格变化的幅度与新闻重要性的关系？

**示例学习过程**：
```
输入给 LLM:
- Week 1: 正面新闻 → 价格上涨 3%
- Week 2: 负面新闻 → 价格下跌 2%
- Week 3: 混合新闻 → 价格微涨 0.5%

LLM 学习到:
"正面新闻通常导致价格上涨，负面新闻导致价格下跌"

然后预测 Week 4:
- 看到新的正面新闻 → 预测价格上涨
```

---

### 原因 2: 提供时间序列上下文

**价格变化趋势**帮助 LLM 理解：
- **价格趋势**：连续上涨 vs 连续下跌 vs 震荡
- **波动幅度**：大涨大跌 vs 小幅波动
- **市场情绪**：整体市场对公司的看法

**示例**：
```
如果过去3周都是上涨趋势：
- LLM 可能认为：市场情绪积极，即使中性新闻也可能继续上涨

如果过去3周是下跌趋势：
- LLM 可能认为：市场情绪消极，需要更强的正面新闻才能扭转
```

---

### 原因 3: 验证新闻影响

**价格变化**可以作为**新闻重要性的验证**：
- 如果某周有重大新闻，但价格变化很小 → 可能新闻影响有限
- 如果某周新闻较少，但价格变化很大 → 可能有其他因素（技术面、市场情绪等）

---

## 📋 完整 Prompt 结构

### 实际发送给 LLM 的 Prompt 示例：

```
[Company Introduction]:
Apple Inc. is a leading entity in the Technology sector...

From 2024-11-03 to 2024-11-10, AAPL's stock price increased from 145.00 to 150.00. 
Company news during this period are listed below:

[Headline]: Apple Launches New iPhone
[Summary]: Apple Inc. announced the launch of its latest iPhone model...

From 2024-11-10 to 2024-11-17, AAPL's stock price increased from 150.00 to 155.00. 
Company news during this period are listed below:

[Headline]: Apple Reports Record Q4 Earnings
[Summary]: Apple Inc. announced record-breaking quarterly earnings...

[Basic Financials]:
revenue: 1000000000
profit: 200000000
...

Based on all the information before 2024-12-01, let's first analyze the positive 
developments and potential concerns for AAPL. Come up with 2-4 most important 
factors respectively and keep them concise. Most factors should be inferred from 
company related news. Then make your prediction of the AAPL stock price movement 
for next week (2024-12-01 to 2024-12-08). Provide a summary analysis to support 
your prediction.
```

---

## 🔄 数据流程

```
1. 获取历史数据 (过去3周)
   ├── 新闻数据 (Finnhub API)
   └── 价格数据 (yfinance) ← Close 价格在这里使用
       ├── Start Price (周初价格)
       └── End Price (周末价格)

2. 构建 Prompt
   ├── 公司介绍
   ├── 历史价格-新闻对应关系 ← Close 价格用于这里
   │   ├── Week 1: 价格变化 + 新闻
   │   ├── Week 2: 价格变化 + 新闻
   │   └── Week 3: 价格变化 + 新闻
   └── 基本面数据

3. LLM 分析
   ├── 学习历史模式
   ├── 分析当前新闻
   └── 预测未来价格

4. 生成信号
   └── 基于预测生成 sentiment_signal (1/-1/0)
```

---

## 💡 关键理解

### Close 价格不是用来做技术分析

**注意**：这里的 Close 价格**不是**用于：
- ❌ 计算技术指标（RSI, MACD 等）
- ❌ 做技术分析
- ❌ 直接预测价格

**而是用于**：
- ✅ 提供历史上下文
- ✅ 帮助 LLM 理解新闻-价格关联
- ✅ 让 LLM 学习模式

---

## 📚 参考：FinGPT 原始设计

这是 **FinGPT_Forecaster** 的标准做法：

1. **训练阶段**：使用历史的价格-新闻数据对训练 LLM
2. **推理阶段**：提供历史价格-新闻对应关系，让 LLM 基于学习到的模式进行预测

**核心思想**：**Few-shot Learning**（少样本学习）
- 通过展示几个历史例子，让 LLM 理解模式
- 然后应用到新的情况

---

## 🎯 总结

**Close 价格在 Sentiment Signal 生成中的作用**：

1. **提供历史上下文**：展示过去几周的价格变化趋势
2. **建立新闻-价格关联**：帮助 LLM 理解哪些新闻导致价格上涨/下跌
3. **支持模式学习**：让 LLM 从历史数据中学习，然后预测未来
4. **验证新闻影响**：价格变化可以作为新闻重要性的参考

**没有 Close 价格会怎样？**
- LLM 只能看到新闻，但不知道这些新闻对价格的实际影响
- 无法学习新闻-价格关联模式
- 预测准确性会大幅下降

这就是为什么 `get_stock_data` 必须返回 Close 价格数据的原因！

