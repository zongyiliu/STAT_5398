# Colab 启用 GPU 指南

## 🚨 问题：没有检测到 GPU

如果看到以下消息：
```
⚠️  No GPU detected. Using CPU (this will be slow)
```

**这意味着 Colab 没有启用 GPU，模型会在 CPU 上运行，速度会非常慢！**

---

## ✅ 解决方案：启用 GPU

### 步骤 1: 打开运行时设置

1. 在 Colab 菜单栏中，点击 **Runtime**（运行时）
2. 选择 **Change runtime type**（更改运行时类型）

### 步骤 2: 选择 GPU

1. 在 **Hardware accelerator**（硬件加速器）下拉菜单中
2. 选择 **GPU**
3. 在 **GPU type** 中选择：
   - **T4**（免费版，推荐）
   - **A100**（付费版，更快）

### 步骤 3: 保存并重启

1. 点击 **Save**（保存）
2. Colab 会自动重启运行时
3. 重新运行代码

---

## 🔍 验证 GPU 是否启用

运行以下代码验证：

```python
import torch

if torch.cuda.is_available():
    print(f"✓ GPU 可用: {torch.cuda.get_device_name(0)}")
    print(f"  显存: {torch.cuda.get_device_properties(0).total_memory / 1e9:.2f} GB")
else:
    print("✗ GPU 未启用")
    print("  请按照上述步骤启用 GPU")
```

**期望输出**：
```
✓ GPU 可用: Tesla T4
  显存: 15.00 GB
```

---

## ⚡ 性能对比

| 设备 | 模型加载时间 | 每个股票推理时间 | 总时间（100个股票） |
|------|-------------|----------------|-------------------|
| **GPU (T4)** | 1-2 分钟 | 1-2 分钟 | 2-4 小时 |
| **CPU** | 10-20 分钟 | 20-30 分钟 | 40-50 小时 |

**结论**：使用 GPU 可以快 **10-20 倍**！

---

## 📋 常见问题

### Q1: 为什么需要 GPU？

**A**: Llama 2 7B 模型有 70 亿参数，在 CPU 上运行非常慢。GPU 的并行计算能力可以大幅加速推理。

### Q2: 免费版有 GPU 吗？

**A**: 是的！Colab 免费版提供 **T4 GPU**，虽然有时限，但足够完成大部分任务。

### Q3: GPU 使用限制？

**A**: 
- 免费版：每天有使用时间限制（通常几小时）
- 如果达到限制，需要等待或升级到付费版

### Q4: 如何检查 GPU 使用情况？

**A**: 运行：
```python
!nvidia-smi
```

### Q5: 如果 GPU 内存不足怎么办？

**A**: 
- 使用更小的模型（如 Llama 3.1 8B）
- 或者使用 `offload_folder` 参数将部分参数卸载到磁盘

---

## 🎯 快速检查清单

在运行代码前，确保：

- [ ] ✅ GPU 已启用（Runtime → Change runtime type → GPU）
- [ ] ✅ 运行时已重启（启用 GPU 后会自动重启）
- [ ] ✅ 验证代码显示 GPU 可用
- [ ] ✅ 所有依赖已安装
- [ ] ✅ API Keys 已设置

---

## 💡 提示

1. **首次启用 GPU**：启用后 Colab 会自动重启，需要重新运行所有代码
2. **保存工作**：启用 GPU 前，确保重要数据已保存到 Google Drive
3. **监控使用**：在 Colab 右上角可以看到 GPU 使用情况
4. **超时处理**：如果长时间无操作，Colab 可能会断开连接，需要重新连接

---

## 🔧 如果仍然没有 GPU

如果按照上述步骤操作后仍然没有 GPU：

1. **检查 Colab 账户**：
   - 确保使用的是 Google 账户登录
   - 某些地区可能有访问限制

2. **尝试刷新**：
   - 刷新页面
   - 重新打开 Colab

3. **检查配额**：
   - 可能已达到每日 GPU 使用限制
   - 等待一段时间后重试

4. **使用 CPU（不推荐）**：
   - 如果必须使用 CPU，请耐心等待
   - 模型加载可能需要 10-20 分钟
   - 每个股票推理可能需要 20-30 分钟

---

## 📝 相关文档

- `COLAB_QUICK_START.md` - Colab 快速开始指南
- `COLAB_FIX_DEVICE_META_ERROR.md` - 设备错误修复说明
- `COLAB_TEST_GUIDE.md` - Colab 测试指南

