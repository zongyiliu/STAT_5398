# Colab 结果下载指南

## 📥 Colab 文件下载方法

Colab **不能直接将文件保存到本地**，但可以通过以下方式获取结果：

---

## 方法 1: 直接下载（推荐）

### 下载单个文件

```python
from google.colab import files

# 下载生成的情感信号文件
files.download('data_processor/outputs/sentiment_signals.csv')
```

### 下载多个文件

```python
from google.colab import files
import os

# 下载所有结果文件
result_files = [
    'data_processor/outputs/sentiment_signals.csv',
    'data_processor/outputs/fusion_results.csv',  # 如果生成了
]

for file_path in result_files:
    if os.path.exists(file_path):
        print(f"下载: {file_path}")
        files.download(file_path)
    else:
        print(f"文件不存在: {file_path}")
```

### 下载整个目录（需要先打包）

```python
from google.colab import files
import zipfile
import os

# 创建结果目录的 ZIP 文件
output_dir = 'data_processor/outputs'
zip_filename = 'results.zip'

with zipfile.ZipFile(zip_filename, 'w', zipfile.ZIP_DEFLATED) as zipf:
    for root, dirs, files in os.walk(output_dir):
        for file in files:
            file_path = os.path.join(root, file)
            arcname = os.path.relpath(file_path, os.path.dirname(output_dir))
            zipf.write(file_path, arcname)

# 下载 ZIP 文件
files.download(zip_filename)
```

---

## 方法 2: 使用 Google Drive（推荐用于大文件）

### 挂载 Google Drive

```python
from google.colab import drive

# 挂载 Google Drive
drive.mount('/content/drive')

# 现在可以访问 /content/drive/MyDrive/
```

### 保存到 Google Drive

```python
import shutil
import os

# 创建 Drive 目录
drive_dir = '/content/drive/MyDrive/Colab_Results'
os.makedirs(drive_dir, exist_ok=True)

# 复制文件到 Drive
shutil.copy(
    'data_processor/outputs/sentiment_signals.csv',
    f'{drive_dir}/sentiment_signals.csv'
)

print(f"✓ 文件已保存到 Google Drive: {drive_dir}")
```

### 从 Google Drive 下载到本地

1. 在浏览器中打开 [Google Drive](https://drive.google.com)
2. 找到保存的文件
3. 右键点击 → 下载

---

## 方法 3: 自动保存脚本

创建一个自动保存脚本，定期将结果保存到 Drive：

```python
import shutil
import os
from datetime import datetime
from google.colab import drive

# 挂载 Drive
drive.mount('/content/drive')

def save_to_drive(file_path, drive_base='/content/drive/MyDrive/Colab_Results'):
    """保存文件到 Google Drive"""
    # 创建带时间戳的目录
    timestamp = datetime.now().strftime('%Y%m%d_%H%M%S')
    drive_dir = os.path.join(drive_base, timestamp)
    os.makedirs(drive_dir, exist_ok=True)
    
    # 复制文件
    filename = os.path.basename(file_path)
    drive_path = os.path.join(drive_dir, filename)
    shutil.copy(file_path, drive_path)
    
    print(f"✓ 已保存到: {drive_path}")
    return drive_path

# 使用示例
save_to_drive('data_processor/outputs/sentiment_signals.csv')
```

---

## 📋 完整下载流程示例

### 在 Colab Notebook 中添加下载单元格

```python
# ============================================================================
# 下载结果文件
# ============================================================================

from google.colab import files
import os

# 检查文件是否存在
output_file = 'data_processor/outputs/sentiment_signals.csv'

if os.path.exists(output_file):
    print(f"准备下载: {output_file}")
    print(f"文件大小: {os.path.getsize(output_file) / 1024 / 1024:.2f} MB")
    
    # 下载文件
    files.download(output_file)
    print("✓ 下载完成！")
else:
    print(f"✗ 文件不存在: {output_file}")
    print("请先运行生成脚本")
```

---

## 🔄 自动保存到 Drive 的完整示例

```python
# ============================================================================
# 自动保存结果到 Google Drive
# ============================================================================

from google.colab import drive
import shutil
import os
from datetime import datetime

# 1. 挂载 Google Drive
print("挂载 Google Drive...")
drive.mount('/content/drive')
print("✓ Drive 已挂载")

# 2. 创建保存目录
drive_base = '/content/drive/MyDrive/Colab_Results'
timestamp = datetime.now().strftime('%Y%m%d_%H%M%S')
save_dir = os.path.join(drive_base, f'sentiment_signals_{timestamp}')
os.makedirs(save_dir, exist_ok=True)
print(f"保存目录: {save_dir}")

# 3. 保存结果文件
files_to_save = [
    'data_processor/outputs/sentiment_signals.csv',
    # 可以添加其他文件
]

for file_path in files_to_save:
    if os.path.exists(file_path):
        filename = os.path.basename(file_path)
        dest_path = os.path.join(save_dir, filename)
        shutil.copy(file_path, dest_path)
        print(f"✓ 已保存: {filename}")
    else:
        print(f"✗ 文件不存在: {file_path}")

print(f"\n✓ 所有文件已保存到 Google Drive")
print(f"路径: {save_dir}")
print("\n从本地访问:")
print("1. 打开 https://drive.google.com")
print("2. 进入 Colab_Results 文件夹")
print("3. 找到对应的文件夹并下载")
```

---

## 💡 最佳实践

### 1. 小文件（<100MB）：直接下载
```python
files.download('sentiment_signals.csv')
```

### 2. 大文件（>100MB）：保存到 Drive
```python
# 保存到 Drive，然后从浏览器下载
shutil.copy('large_file.csv', '/content/drive/MyDrive/')
```

### 3. 多个文件：打包下载
```python
# 创建 ZIP 文件
import zipfile
with zipfile.ZipFile('results.zip', 'w') as zipf:
    zipf.write('file1.csv')
    zipf.write('file2.csv')

# 下载 ZIP
files.download('results.zip')
```

### 4. 定期自动保存
```python
# 在生成过程中定期保存
if len(results) % 100 == 0:
    # 保存到 Drive
    save_to_drive('intermediate_results.csv')
```

---

## ⚠️ 注意事项

### 1. 文件大小限制
- **直接下载**: 建议 <100MB
- **大文件**: 使用 Google Drive

### 2. 下载位置
- 文件会下载到浏览器的默认下载目录
- 可以在浏览器设置中更改下载位置

### 3. 网络稳定性
- 确保网络连接稳定
- 大文件下载可能需要较长时间

### 4. Drive 存储空间
- 免费版 Google Drive: 15GB
- 如果空间不足，需要清理或升级

---

## 📝 更新后的 Colab Notebook 模板

在您的 Colab notebook 最后添加：

```python
# ============================================================================
# 步骤 9: 下载结果（选择一种方法）
# ============================================================================

# 方法 1: 直接下载（小文件）
from google.colab import files
files.download('data_processor/outputs/sentiment_signals.csv')

# 方法 2: 保存到 Google Drive（大文件或需要保留）
# from google.colab import drive
# import shutil
# drive.mount('/content/drive')
# shutil.copy(
#     'data_processor/outputs/sentiment_signals.csv',
#     '/content/drive/MyDrive/sentiment_signals.csv'
# )
```

---

## 🎯 推荐方案

### 对于 `sentiment_signals.csv`（通常 <50MB）

**推荐**: 直接下载
```python
files.download('data_processor/outputs/sentiment_signals.csv')
```

### 对于完整结果（包含多个文件）

**推荐**: 打包后下载
```python
# 创建 ZIP
import zipfile
with zipfile.ZipFile('all_results.zip', 'w') as zipf:
    zipf.write('sentiment_signals.csv')
    zipf.write('fusion_results.csv')
    # ... 其他文件

# 下载
files.download('all_results.zip')
```

### 对于需要长期保存的结果

**推荐**: 保存到 Google Drive
```python
drive.mount('/content/drive')
shutil.copy('results.csv', '/content/drive/MyDrive/')
```

---

## 📊 总结

| 方法 | 适用场景 | 优点 | 缺点 |
|------|---------|------|------|
| **直接下载** | 小文件 (<100MB) | 简单快速 | 文件大小限制 |
| **Google Drive** | 大文件或需要保留 | 无大小限制，可长期保存 | 需要手动从 Drive 下载 |
| **ZIP 打包** | 多个文件 | 一次下载所有文件 | 需要额外打包步骤 |

**结论**: Colab 不能直接保存到本地，但可以通过下载或 Drive 的方式获取文件。

