# generate_sentiment_signals.py 逻辑阐述

## 📋 概述

`generate_sentiment_signals.py` 是一个专门用于生成情感分析信号的脚本。它只运行 `news_fetcher` 和 `sentiment_agent` 两个模块，为选中的股票生成基于新闻情感的交易信号。

---

## 🎯 核心目标

**输入**: `stock_selected.csv` (股票选择结果)  
**输出**: `sentiment_signals.csv` (情感分析信号)

---

## 🔄 整体流程

```
1. 加载数据
   ├── 加载 stock_selected.csv
   └── 构建 gvkey → ticker 映射

2. 初始化组件
   ├── 初始化 SentimentAgent (FinGPT 模型)
   └── 初始化 NewsDataFetcher (新闻获取器)

3. 生成情感信号
   ├── 对每个 (trade_date, gvkey) 组合:
   │   ├── 获取新闻数据 (过去3周)
   │   ├── 运行 FinGPT 分析
   │   └── 生成情感信号
   └── 保存结果到 CSV

4. 输出
   └── sentiment_signals.csv
```

---

## 📝 详细逻辑说明

### 阶段 1: 数据加载 (`load_selected_stocks`)

**功能**: 加载股票选择结果

```python
def load_selected_stocks(data_dir):
    # 1. 定位 stock_selected.csv 文件
    stock_selected_file = os.path.join(data_dir, "stock_selected.csv")
    
    # 2. 检查文件是否存在
    if not os.path.exists(stock_selected_file):
        raise FileNotFoundError(...)
    
    # 3. 读取 CSV 文件
    df = pd.read_csv(stock_selected_file)
    
    # 4. 转换日期格式
    df['trade_date'] = pd.to_datetime(df['trade_date'])
    
    return df
```

**输入格式** (`stock_selected.csv`):
```csv
gvkey,trade_date,predicted_return
1078,2024-12-01,0.05
1161,2024-12-01,0.03
...
```

**输出**: DataFrame 包含所有选中的股票及其交易日期

---

### 阶段 2: 构建映射 (`build_gvkey_to_ticker_map`)

**功能**: 将 gvkey (数据库标识符) 映射到 ticker (股票代码)

**为什么需要这个映射?**
- `stock_selected.csv` 使用 `gvkey` (如 1078)
- 新闻 API (Finnhub) 需要 `ticker` (如 "AAPL")
- 需要建立两者之间的对应关系

```python
def build_gvkey_to_ticker_map(price_file_path):
    # 1. 创建 NewsDataFetcher 实例
    fetcher = NewsDataFetcher()
    
    # 2. 从价格数据文件中构建映射
    mapping = fetcher.build_gvkey_to_ticker_map(price_file_path)
    
    # 返回字典: {gvkey: ticker}
    return mapping
```

**映射示例**:
```python
{
    1078: "AAPL",   # Apple
    1161: "MSFT",   # Microsoft
    1230: "GOOGL",  # Google
    ...
}
```

---

### 阶段 3: 初始化组件

#### 3.1 初始化 SentimentAgent

**功能**: 加载 FinGPT 模型用于情感分析

```python
sentiment_agent = SentimentAgent()
```

**内部流程**:
1. 加载基础模型: `meta-llama/Llama-2-7b-chat-hf`
2. 加载 LoRA 适配器: `FinGPT/fingpt-forecaster_dow30_llama2-7b_lora`
3. 加载 tokenizer
4. 初始化 PromptBuilder

**注意**: 这一步需要 GPU 和 HuggingFace Token，可能需要较长时间

#### 3.2 初始化 NewsDataFetcher

**功能**: 创建新闻数据获取器

```python
news_fetcher = NewsDataFetcher()
```

**内部流程**:
1. 从环境变量获取 Finnhub API Key
2. 创建 Finnhub 客户端

---

### 阶段 4: 生成情感信号 (`generate_sentiment_signals`)

这是核心函数，包含完整的信号生成逻辑。

#### 4.1 数据过滤

```python
# 按日期过滤
if start_date:
    selected_stocks = selected_stocks[
        selected_stocks['trade_date'] >= pd.to_datetime(start_date)
    ]
if end_date:
    selected_stocks = selected_stocks[
        selected_stocks['trade_date'] <= pd.to_datetime(end_date)
    ]

# 测试模式：限制股票数量
if max_stocks:
    unique_gvkeys = selected_stocks['gvkey'].unique()[:max_stocks]
    selected_stocks = selected_stocks[
        selected_stocks['gvkey'].isin(unique_gvkeys)
    ]
```

#### 4.2 断点续传机制

**功能**: 如果输出文件已存在，跳过已处理的记录

```python
existing_results = {}
if resume and os.path.exists(output_file):
    # 加载已有结果
    existing_df = pd.read_csv(output_file)
    for _, row in existing_df.iterrows():
        key = (row['gvkey'], row['trade_date'])
        existing_results[key] = row.to_dict()
```

**优势**:
- 支持中断后继续运行
- 避免重复计算
- 节省时间和 API 调用

#### 4.3 分组处理

```python
# 按 (trade_date, gvkey) 分组
grouped = selected_stocks.groupby(['trade_date', 'gvkey'])

# 遍历每个组合
for (trade_date, gvkey), group in grouped:
    # 处理逻辑...
```

**为什么分组?**
- 同一个股票在同一个交易日期可能有多条记录
- 分组确保每个 (日期, 股票) 组合只处理一次

#### 4.4 核心处理循环

对每个 `(trade_date, gvkey)` 组合：

```python
# 1. 检查是否已处理
key = (gvkey, trade_date)
if key in existing_results:
    results.append(existing_results[key])
    continue  # 跳过

# 2. 获取 ticker
ticker = gvkey_to_ticker.get(gvkey)
if ticker is None:
    print(f"Warning: No ticker found for gvkey {gvkey}")
    continue  # 跳过

# 3. 获取新闻数据
news_data = news_fetcher.fetch_all_data(
    ticker, 
    trade_date_str, 
    n_weeks=3  # 过去3周的新闻
)

# 4. 运行 FinGPT 分析
sentiment_result = sentiment_agent.analyze(
    news_data=news_data,
    symbol=ticker,
    date=trade_date_str,
    n_weeks=3
)

# 5. 提取结果
result = {
    'trade_date': trade_date_str,
    'gvkey': gvkey,
    'ticker': ticker,
    'sentiment_signal': sentiment_result.get('signal', 0),      # -1, 0, 1
    'sentiment_confidence': sentiment_result.get('confidence', 0.5),  # 0-1
    'predicted_return': sentiment_result.get('predicted_return', 0.0),
    'positive_count': sentiment_result.get('positive_count', 0),
    'negative_count': sentiment_result.get('negative_count', 0),
    'raw_output': sentiment_result.get('raw_output', '')[:500]
}

results.append(result)
```

#### 4.5 新闻数据获取 (`fetch_all_data`)

**功能**: 获取过去3周的新闻和股票数据

**内部流程**:
1. 计算日期范围: `[trade_date - 3周, trade_date]`
2. 获取新闻: 调用 Finnhub API
3. 获取股票价格: 调用 yfinance
4. 格式化数据: 转换为 FinGPT 需要的格式

**返回格式**:
```python
{
    'News': json.dumps(news_list),  # JSON 字符串
    'Stock': stock_data_dict,       # 股票数据字典
    ...
}
```

#### 4.6 FinGPT 分析 (`sentiment_agent.analyze`)

**功能**: 使用 FinGPT 模型分析新闻情感

**内部流程**:
1. **构建 Prompt**:
   ```python
   info, prompt = self.prompt_builder.get_all_prompts_online(
       symbol, news_data, date, with_basics=True
   )
   ```
   
   包含:
   - 新闻数据 (过去3周)
   - 股票基本信息 (价格、市值等)
   - 系统提示词

2. **格式化 Prompt**:
   ```python
   formatted_prompt = (
       self.B_INST + self.B_SYS + self.SYSTEM_PROMPT + self.E_SYS + 
       prompt + self.E_INST
   )
   ```

3. **模型推理**:
   ```python
   inputs = self.tokenizer(formatted_prompt, return_tensors='pt')
   res = self.model.generate(
       **inputs,
       max_length=4096,
       temperature=0.7,
       top_p=0.9
   )
   ```

4. **解析输出**:
   ```python
   output = self.tokenizer.decode(res[0], skip_special_tokens=True)
   result = self._parse_output(output, symbol)
   ```

**输出格式**:
```python
{
    'signal': 1,              # -1 (sell), 0 (hold), 1 (buy)
    'confidence': 0.85,        # 0-1
    'predicted_return': 0.05,  # 预测收益率 (5%)
    'positive_count': 3,       # 正面新闻数量
    'negative_count': 1,       # 负面新闻数量
    'raw_output': "..."        # 原始模型输出
}
```

#### 4.7 结果保存

**增量保存**: 每处理10条记录保存一次
```python
if len(results) % 10 == 0:
    df_results = pd.DataFrame(results)
    df_results.to_csv(output_file, index=False)
```

**最终保存**: 处理完成后保存所有结果
```python
df_results = pd.DataFrame(results)
df_results.to_csv(output_file, index=False)
```

---

## 📊 输出文件格式

### `sentiment_signals.csv`

```csv
trade_date,gvkey,ticker,sentiment_signal,sentiment_confidence,predicted_return,positive_count,negative_count,raw_output
2024-12-01,1078,AAPL,1,0.85,0.05,3,1,"[Positive Developments]:..."
2024-12-01,1161,MSFT,0,0.60,0.02,2,2,"[Positive Developments]:..."
...
```

**字段说明**:
- `trade_date`: 交易日期
- `gvkey`: 股票唯一标识符
- `ticker`: 股票代码
- `sentiment_signal`: 情感信号 (-1, 0, 1)
- `sentiment_confidence`: 置信度 (0-1)
- `predicted_return`: 预测收益率
- `positive_count`: 正面新闻数量
- `negative_count`: 负面新闻数量
- `raw_output`: 原始模型输出 (截断到500字符)

---

## 🔧 关键特性

### 1. 断点续传
- 支持中断后继续运行
- 自动跳过已处理的记录
- 避免重复计算

### 2. 错误处理
- 单个股票失败不影响其他股票
- 记录错误但不中断流程
- 提供详细的错误信息

### 3. 进度可视化
- 使用 `tqdm` 显示进度条
- 实时显示当前处理的股票和日期
- 显示处理速度和剩余时间

### 4. 测试模式
- 支持 `--max_stocks` 限制股票数量
- 支持日期范围过滤
- 便于快速测试

### 5. 增量保存
- 每10条记录保存一次
- 避免数据丢失
- 支持实时查看结果

---

## 🚀 使用示例

### 完整运行
```bash
python generate_sentiment_signals.py
```

### 测试模式 (5只股票)
```bash
python generate_sentiment_signals.py --max_stocks 5
```

### 指定日期范围
```bash
python generate_sentiment_signals.py \
    --start_date "2024-12-01" \
    --end_date "2024-12-31"
```

### 不续传 (重新生成)
```bash
python generate_sentiment_signals.py --no_resume
```

---

## ⚠️ 注意事项

### 1. API 限制
- **Finnhub API**: 60 calls/minute
- 脚本会自动处理速率限制
- 建议在 Colab 上运行 (更稳定)

### 2. 计算资源
- **GPU 必需**: FinGPT 模型需要 GPU
- **内存需求**: 至少 16GB RAM
- **推荐**: Google Colab A100 GPU

### 3. 时间消耗
- **单只股票**: 约 10-30 秒
- **100只股票**: 约 20-50 分钟
- **完整数据**: 可能需要数小时

### 4. 数据依赖
- 需要 `stock_selected.csv` 存在
- 需要价格数据文件用于映射
- 需要有效的 API keys

---

## 🔗 与其他模块的关系

```
generate_sentiment_signals.py
    ├── 输入: stock_selected.csv (来自 stock_selection.py)
    ├── 使用: NewsDataFetcher (获取新闻)
    ├── 使用: SentimentAgent (FinGPT 分析)
    └── 输出: sentiment_signals.csv (用于 fuse_signals.py)
```

---

## 📈 数据流

```
stock_selected.csv
    ↓
[加载] → DataFrame
    ↓
[映射] → gvkey → ticker
    ↓
[循环] 对每个 (trade_date, gvkey):
    ├── 获取新闻 (过去3周)
    ├── 运行 FinGPT 分析
    └── 生成情感信号
    ↓
[保存] → sentiment_signals.csv
```

---

## 💡 设计亮点

1. **模块化设计**: 清晰的函数分离，易于维护
2. **容错机制**: 单个失败不影响整体
3. **断点续传**: 支持长时间运行
4. **进度可视化**: 实时反馈处理状态
5. **灵活配置**: 支持多种运行模式

---

## 📝 总结

`generate_sentiment_signals.py` 是一个专门用于生成情感分析信号的脚本。它通过以下步骤实现：

1. **加载** 选中的股票列表
2. **映射** gvkey 到 ticker
3. **获取** 新闻数据 (过去3周)
4. **分析** 使用 FinGPT 模型
5. **生成** 情感信号
6. **保存** 结果到 CSV

整个过程设计为**容错**、**可恢复**、**可视化**，适合处理大量数据。

