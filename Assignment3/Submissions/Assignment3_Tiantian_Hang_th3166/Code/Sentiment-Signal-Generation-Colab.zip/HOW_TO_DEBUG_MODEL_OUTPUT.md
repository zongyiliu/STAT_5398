# 如何检查模型是否正确生成输出

## 问题描述

如果测试输出文件中的 `sentiment_signal` 都是 0，`sentiment_confidence` 都是 0.5（默认值），并且 `raw_output` 只包含 prompt 而没有模型的实际输出，说明模型可能没有正确生成输出。

## 调试方法

### 方法 1: 使用调试脚本（推荐）

运行专门的调试脚本来检查模型输出：

```bash
# 基本用法
python debug_model_output.py --symbol AAPL --date 2024-12-01

# 使用不同的股票和日期
python debug_model_output.py --symbol NBR --date 2024-12-01

# 调整回溯周数
python debug_model_output.py --symbol AAPL --date 2024-12-01 --n_weeks 3
```

**调试脚本会检查：**
1. ✅ SentimentAgent 是否正确初始化
2. ✅ 是否成功获取新闻数据
3. ✅ Prompt 是否正确构建
4. ✅ 输入是否正确 tokenize
5. ✅ 模型是否生成了新内容（输出长度 > prompt 长度）
6. ✅ 是否找到了 Prediction 模式
7. ✅ 输出解析结果

**输出文件：**
- 调试脚本会生成 `debug_output_{symbol}_{date}.txt` 文件，包含完整的模型输出

### 方法 2: 在代码中添加调试输出

修改 `signal_generator/sentiment_agent.py` 的 `analyze` 方法，添加调试输出：

```python
def analyze(self, news_data, symbol, date, n_weeks=3):
    # ... (现有代码) ...
    
    output = self.tokenizer.decode(res[0], skip_special_tokens=True)
    
    # 添加调试输出
    print(f"\n{'='*80}")
    print(f"调试信息 - {symbol} ({date})")
    print(f"{'='*80}")
    print(f"Prompt 长度: {len(formatted_prompt)} 字符")
    print(f"输出总长度: {len(output)} 字符")
    print(f"模型生成部分长度: {len(output) - len(formatted_prompt)} 字符")
    
    # 检查输出是否包含新内容
    if len(output) > len(formatted_prompt):
        model_generated = output[len(formatted_prompt):].strip()
        print(f"\n✓ 模型生成了新内容 ({len(model_generated)} 字符)")
        print(f"前 200 字符: {model_generated[:200]}...")
    else:
        print(f"\n❌ 警告: 模型没有生成新内容！")
        print(f"输出可能只包含 prompt")
    
    # 检查是否包含 Prediction
    if 'prediction' in output.lower():
        print(f"✓ 输出包含 'prediction' 关键词")
    else:
        print(f"⚠️  输出不包含 'prediction' 关键词")
    
    # Parse output
    result = self._parse_output(output, symbol)
    
    # 显示解析结果
    print(f"\n解析结果:")
    print(f"  Signal: {result['signal']}")
    print(f"  Confidence: {result['confidence']}")
    print(f"  Predicted Return: {result['predicted_return']}")
    print(f"{'='*80}\n")
    
    result['raw_output'] = output
    return result
```

### 方法 3: 检查模型生成参数

检查 `model.generate()` 的参数是否正确：

```python
# 在 sentiment_agent.py 中检查
res = self.model.generate(
    **inputs,
    max_length=4096,        # 确保足够大
    do_sample=True,         # 启用采样
    eos_token_id=self.tokenizer.eos_token_id,  # 确保设置了 EOS token
    use_cache=True,
    temperature=0.7,        # 温度参数
    top_p=0.9              # top-p 采样
)
```

**常见问题：**
- `max_length` 太小：如果 `max_length` 等于或接近输入长度，模型无法生成新内容
- `eos_token_id` 未设置：模型可能不知道何时停止生成
- `do_sample=False`：使用贪婪解码，可能生成重复内容

### 方法 4: 检查模型状态

在生成前检查模型状态：

```python
# 检查模型是否在 eval 模式
print(f"模型 eval 模式: {self.model.training == False}")

# 检查模型设备
print(f"模型设备: {self.model.device if hasattr(self.model, 'device') else 'multiple devices'}")

# 检查输入设备
print(f"输入设备: {target_device}")

# 检查输入形状
print(f"输入形状: {inputs['input_ids'].shape}")
```

### 方法 5: 手动测试模型生成

创建一个简单的测试脚本：

```python
from signal_generator.sentiment_agent import SentimentAgent

# 初始化
agent = SentimentAgent()

# 简单的测试 prompt
test_prompt = "[INST]<<SYS>>\nYou are a stock analyst.\n<</SYS>>\n\nAnalyze AAPL stock.\n[/INST]"

# Tokenize
inputs = agent.tokenizer(test_prompt, return_tensors='pt')
inputs = {key: value.to(agent.device) for key, value in inputs.items()}

# 生成
import torch
with torch.no_grad():
    res = agent.model.generate(
        **inputs,
        max_length=512,  # 较小的长度用于快速测试
        do_sample=True,
        temperature=0.7,
        top_p=0.9
    )

# 解码
output = agent.tokenizer.decode(res[0], skip_special_tokens=True)
print(f"输入长度: {len(test_prompt)}")
print(f"输出长度: {len(output)}")
print(f"新生成: {len(output) - len(test_prompt)} 字符")
print(f"\n输出:\n{output}")
```

## 常见问题和解决方案

### 问题 1: 输出长度 = Prompt 长度

**原因：**
- 模型没有生成新内容
- `max_length` 设置太小
- 模型生成立即遇到 EOS token

**解决方案：**
- 检查 `max_length` 是否足够大（建议 >= 输入长度 + 500）
- 检查模型是否正确加载
- 检查设备是否正确（CPU vs GPU）

### 问题 2: 找不到 Prediction 模式

**原因：**
- 模型输出格式不符合预期
- 正则表达式不匹配

**解决方案：**
- 查看完整的 `raw_output`，检查模型实际输出格式
- 调整 `_parse_output` 中的正则表达式
- 考虑使用更灵活的解析方法

### 问题 3: 所有 Signal 都是 0

**原因：**
- 模型预测的收益率在 ±2% 范围内（根据代码逻辑，只有 > 2% 或 < -2% 才会生成非 0 信号）
- 模型输出解析失败，使用了默认值

**解决方案：**
- 检查 `predicted_return` 的值
- 如果 `predicted_return` 在 -0.02 到 0.02 之间，signal 为 0 是正常的
- 如果 `predicted_return` 为 0.0，说明解析失败

### 问题 4: 模型生成速度很慢

**原因：**
- 使用 CPU 而不是 GPU
- 模型太大
- `max_length` 设置太大

**解决方案：**
- 确保使用 GPU（在 Colab 中启用 GPU）
- 考虑使用更小的模型
- 适当减小 `max_length`

## 调试检查清单

- [ ] SentimentAgent 成功初始化
- [ ] 模型正确加载（没有错误信息）
- [ ] 设备正确（GPU 或 CPU）
- [ ] 成功获取新闻数据
- [ ] Prompt 正确构建
- [ ] 输入正确 tokenize
- [ ] 模型生成新内容（输出长度 > prompt 长度）
- [ ] 输出包含 "Prediction" 关键词
- [ ] 输出解析成功（predicted_return 不为 0 或 signal 不为 0）
- [ ] `raw_output` 包含完整的模型输出（不只是 prompt）

## 下一步

如果调试脚本发现问题：

1. **模型没有生成新内容**：
   - 检查模型是否正确加载
   - 检查设备是否正确
   - 检查 `max_length` 参数

2. **找不到 Prediction 模式**：
   - 查看完整的 `raw_output`
   - 调整解析逻辑

3. **所有 Signal 都是 0**：
   - 检查 `predicted_return` 的值
   - 如果预测收益率在 ±2% 范围内，这是正常的

4. **其他问题**：
   - 查看完整的错误信息
   - 检查模型和 tokenizer 的版本兼容性

