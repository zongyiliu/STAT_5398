#!/usr/bin/env python3
"""
Fuse Technical and Sentiment Signals
Loads technical signals from weights file and sentiment signals from CSV
Tests different fusion strategies and finds optimal weights
"""

import os
import sys
import pandas as pd
import numpy as np
from itertools import product
from tqdm import tqdm

# Add project root to path
sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))

from portfolio_manager.portfolio_manager import PortfolioManager
from backtester.backtester_quarterly import QuarterlyBacktester


def load_technical_signals(weights_file):
    """
    Load technical signals from weights file
    
    Args:
        weights_file: Path to weights Excel file (mean_weighted.xlsx)
        
    Returns:
        DataFrame with technical signals
    """
    print(f"Loading technical signals from {weights_file}...")
    df = pd.read_excel(weights_file)
    df['trade_date'] = pd.to_datetime(df['trade_date'])
    print(f"  Loaded {len(df)} records")
    print(f"  Date range: {df['trade_date'].min()} to {df['trade_date'].max()}")
    return df


def load_sentiment_signals(sentiment_file):
    """
    Load sentiment signals from CSV
    
    Args:
        sentiment_file: Path to sentiment_signals.csv
        
    Returns:
        DataFrame with sentiment signals
    """
    print(f"Loading sentiment signals from {sentiment_file}...")
    df = pd.read_csv(sentiment_file)
    df['trade_date'] = pd.to_datetime(df['trade_date'])
    print(f"  Loaded {len(df)} records")
    print(f"  Date range: {df['trade_date'].min()} to {df['trade_date'].max()}")
    return df


def merge_signals(technical_df, sentiment_df):
    """
    Merge technical and sentiment signals
    
    Args:
        technical_df: DataFrame with technical signals
        sentiment_df: DataFrame with sentiment signals
        
    Returns:
        Merged DataFrame
    """
    print("\nMerging signals...")
    
    # Merge on trade_date and gvkey
    merged = pd.merge(
        technical_df,
        sentiment_df,
        on=['trade_date', 'gvkey'],
        how='inner',
        suffixes=('_tech', '_sent')
    )
    
    print(f"  Merged records: {len(merged)}")
    print(f"  Unique trade dates: {merged['trade_date'].nunique()}")
    print(f"  Unique stocks: {merged['gvkey'].nunique()}")
    
    return merged


def test_fusion_weights(merged_df, price_data, selected_stocks, weight_combinations):
    """
    Test different weight combinations
    
    Args:
        merged_df: Merged DataFrame with both signals
        price_data: Price data DataFrame
        selected_stocks: Selected stocks DataFrame
        weight_combinations: List of (w_sentiment, w_technical) tuples
        
    Returns:
        DataFrame with results for each weight combination
    """
    print("\nTesting fusion weights...")
    print(f"  Testing {len(weight_combinations)} weight combinations")
    
    results = []
    
    for w_sentiment, w_technical in tqdm(weight_combinations, desc="Testing weights"):
        # Create portfolio manager with custom weights
        class CustomPortfolioManager(PortfolioManager):
            def _weighted_fusion(self, sentiment, technical):
                # Override with custom weights
                sentiment_conf = sentiment.get('confidence', 0.5)
                technical_conf = technical.get('confidence', 0.5)
                
                weighted_score = (
                    sentiment['signal'] * w_sentiment * sentiment_conf +
                    technical['signal'] * w_technical * technical_conf
                )
                
                if weighted_score > 0.4:
                    action = 'BUY'
                elif weighted_score < -0.4:
                    action = 'SELL'
                else:
                    action = 'HOLD'
                
                return {
                    'action': action,
                    'confidence': min(abs(weighted_score), 1.0),
                    'reasoning': f"Custom weights: sentiment={w_sentiment}, technical={w_technical}",
                    'weights': {'sentiment': w_sentiment, 'technical': w_technical},
                    'raw_score': weighted_score
                }
        
        # Create weights DataFrame from merged signals
        weights_df = create_weights_from_signals(merged_df, w_sentiment, w_technical)
        
        # Run backtest
        try:
            backtester = QuarterlyBacktester(
                price_data=price_data,
                selected_stocks=selected_stocks
            )
            
            # Build portfolio returns
            port_ret = backtester.build_portfolio_daily_returns(weights_df)
            
            # Calculate metrics
            total_return = (port_ret.iloc[-1] / port_ret.iloc[0] - 1) * 100
            returns = port_ret.pct_change().dropna()
            
            if len(returns) > 0:
                sharpe_ratio = returns.mean() / returns.std() * np.sqrt(252) if returns.std() > 0 else 0
                
                # Max drawdown
                cumulative = (1 + returns).cumprod()
                running_max = cumulative.expanding().max()
                drawdown = (cumulative - running_max) / running_max
                max_drawdown = drawdown.min() * 100
            else:
                sharpe_ratio = 0
                max_drawdown = 0
            
            results.append({
                'w_sentiment': w_sentiment,
                'w_technical': w_technical,
                'total_return': total_return,
                'sharpe_ratio': sharpe_ratio,
                'max_drawdown': max_drawdown,
                'final_value': port_ret.iloc[-1] if len(port_ret) > 0 else 0
            })
        
        except Exception as e:
            print(f"\nError testing weights ({w_sentiment}, {w_technical}): {e}")
            continue
    
    return pd.DataFrame(results)


def create_weights_from_signals(merged_df, w_sentiment, w_technical):
    """
    Create weights DataFrame from merged signals
    
    Args:
        merged_df: Merged DataFrame with both signals
        w_sentiment: Weight for sentiment signal
        w_technical: Weight for technical signal
        
    Returns:
        DataFrame with weights
    """
    # Convert signals to weights
    # Signal: -1 (sell), 0 (hold), 1 (buy)
    # Weight: positive for buy, negative for sell, zero for hold
    
    weights_list = []
    
    for trade_date in merged_df['trade_date'].unique():
        date_df = merged_df[merged_df['trade_date'] == trade_date]
        
        for _, row in date_df.iterrows():
            # Get signals
            sentiment_signal = row.get('sentiment_signal', 0)
            sentiment_conf = row.get('sentiment_confidence', 0.5)
            
            # Technical signal from weight (if available)
            # For now, use a simple conversion
            technical_weight = row.get('weight', 0)  # From weights file
            
            # Combine signals
            combined_weight = (
                sentiment_signal * w_sentiment * sentiment_conf +
                technical_weight * w_technical
            )
            
            # Normalize to sum to 1 for each trade_date
            weights_list.append({
                'trade_date': trade_date,
                'gvkey': row['gvkey'],
                'weight': combined_weight
            })
    
    weights_df = pd.DataFrame(weights_list)
    
    # Normalize weights per trade_date
    for trade_date in weights_df['trade_date'].unique():
        date_weights = weights_df[weights_df['trade_date'] == trade_date]
        total_weight = date_weights['weight'].abs().sum()
        if total_weight > 0:
            weights_df.loc[weights_df['trade_date'] == trade_date, 'weight'] = (
                weights_df.loc[weights_df['trade_date'] == trade_date, 'weight'] / total_weight
            )
    
    # Ensure no negative weights (no short selling)
    weights_df['weight'] = weights_df['weight'].clip(lower=0)
    
    # Renormalize after clipping
    for trade_date in weights_df['trade_date'].unique():
        date_weights = weights_df[weights_df['trade_date'] == trade_date]
        total_weight = date_weights['weight'].sum()
        if total_weight > 0:
            weights_df.loc[weights_df['trade_date'] == trade_date, 'weight'] = (
                weights_df.loc[weights_df['trade_date'] == trade_date, 'weight'] / total_weight
            )
    
    return weights_df


def find_optimal_weights(results_df):
    """
    Find optimal weight combination
    
    Args:
        results_df: DataFrame with test results
        
    Returns:
        dict with optimal weights and metrics
    """
    if len(results_df) == 0:
        return None
    
    # Find best by different metrics
    best_return = results_df.loc[results_df['total_return'].idxmax()]
    best_sharpe = results_df.loc[results_df['sharpe_ratio'].idxmax()]
    best_drawdown = results_df.loc[results_df['max_drawdown'].idxmax()]  # Least negative
    
    # Composite score (weighted combination)
    results_df['composite_score'] = (
        results_df['total_return'] * 0.4 +
        results_df['sharpe_ratio'] * 100 * 0.4 +
        results_df['max_drawdown'] * 0.2  # Less negative is better
    )
    best_composite = results_df.loc[results_df['composite_score'].idxmax()]
    
    return {
        'best_return': best_return.to_dict(),
        'best_sharpe': best_sharpe.to_dict(),
        'best_drawdown': best_drawdown.to_dict(),
        'best_composite': best_composite.to_dict(),
        'all_results': results_df
    }


def main():
    """Main function"""
    import argparse
    
    parser = argparse.ArgumentParser(
        description='Fuse Technical and Sentiment Signals',
        formatter_class=argparse.RawDescriptionHelpFormatter
    )
    
    parser.add_argument(
        '--technical_file',
        type=str,
        default='data_processor/outputs/mean_weighted.xlsx',
        help='Path to technical weights file'
    )
    
    parser.add_argument(
        '--sentiment_file',
        type=str,
        default='data_processor/outputs/sentiment_signals.csv',
        help='Path to sentiment signals CSV file'
    )
    
    parser.add_argument(
        '--price_file',
        type=str,
        default='../dec data/sp500_tickers_daily_price.csv',
        help='Path to price data file'
    )
    
    parser.add_argument(
        '--selected_stocks_file',
        type=str,
        default='data_processor/outputs/stock_selected.csv',
        help='Path to selected stocks file'
    )
    
    parser.add_argument(
        '--output_file',
        type=str,
        default='data_processor/outputs/fusion_results.csv',
        help='Output CSV file with test results'
    )
    
    parser.add_argument(
        '--weight_step',
        type=float,
        default=0.1,
        help='Step size for weight grid search (default: 0.1)'
    )
    
    args = parser.parse_args()
    
    print("=" * 80)
    print("Fuse Technical and Sentiment Signals")
    print("=" * 80)
    print(f"Technical file: {args.technical_file}")
    print(f"Sentiment file: {args.sentiment_file}")
    print(f"Output file: {args.output_file}")
    print("=" * 80)
    
    try:
        # Load signals
        print("\n[1/4] Loading signals...")
        technical_df = load_technical_signals(args.technical_file)
        sentiment_df = load_sentiment_signals(args.sentiment_file)
        
        # Merge signals
        print("\n[2/4] Merging signals...")
        merged_df = merge_signals(technical_df, sentiment_df)
        
        if len(merged_df) == 0:
            print("✗ No overlapping records found. Check date ranges and gvkeys.")
            return 1
        
        # Generate weight combinations
        print("\n[3/4] Generating weight combinations...")
        weight_combinations = []
        for w_sentiment in np.arange(0, 1.01, args.weight_step):
            w_technical = 1 - w_sentiment
            weight_combinations.append((w_sentiment, w_technical))
        
        print(f"  Testing {len(weight_combinations)} combinations")
        
        # Load price data and selected stocks for backtesting
        print("\nLoading price data and selected stocks...")
        price_data = pd.read_csv(args.price_file, usecols=['gvkey', 'tic', 'datadate', 'prccd', 'ajexdi'])
        selected_stocks = pd.read_csv(args.selected_stocks_file)
        selected_stocks['trade_date'] = pd.to_datetime(selected_stocks['trade_date'])
        
        # Test weight combinations
        print("\n[4/4] Testing weight combinations...")
        results_df = test_fusion_weights(
            merged_df=merged_df,
            price_data=price_data,
            selected_stocks=selected_stocks,
            weight_combinations=weight_combinations
        )
        
        # Find optimal weights
        print("\nFinding optimal weights...")
        optimal = find_optimal_weights(results_df)
        
        if optimal:
            print("\n" + "=" * 80)
            print("Optimal Weight Combinations")
            print("=" * 80)
            print("\nBest by Total Return:")
            print(f"  Weights: sentiment={optimal['best_return']['w_sentiment']:.2f}, technical={optimal['best_return']['w_technical']:.2f}")
            print(f"  Total Return: {optimal['best_return']['total_return']:.2f}%")
            print(f"  Sharpe Ratio: {optimal['best_return']['sharpe_ratio']:.4f}")
            print(f"  Max Drawdown: {optimal['best_return']['max_drawdown']:.2f}%")
            
            print("\nBest by Sharpe Ratio:")
            print(f"  Weights: sentiment={optimal['best_sharpe']['w_sentiment']:.2f}, technical={optimal['best_sharpe']['w_technical']:.2f}")
            print(f"  Total Return: {optimal['best_sharpe']['total_return']:.2f}%")
            print(f"  Sharpe Ratio: {optimal['best_sharpe']['sharpe_ratio']:.4f}")
            print(f"  Max Drawdown: {optimal['best_sharpe']['max_drawdown']:.2f}%")
            
            print("\nBest by Composite Score:")
            print(f"  Weights: sentiment={optimal['best_composite']['w_sentiment']:.2f}, technical={optimal['best_composite']['w_technical']:.2f}")
            print(f"  Total Return: {optimal['best_composite']['total_return']:.2f}%")
            print(f"  Sharpe Ratio: {optimal['best_composite']['sharpe_ratio']:.4f}")
            print(f"  Max Drawdown: {optimal['best_composite']['max_drawdown']:.2f}%")
            print("=" * 80)
        
        # Save results
        results_df.to_csv(args.output_file, index=False)
        print(f"\n✓ Saved results to {args.output_file}")
        
        return 0
        
    except Exception as e:
        print(f"\n✗ Error: {e}")
        import traceback
        traceback.print_exc()
        return 1


if __name__ == "__main__":
    sys.exit(main())


