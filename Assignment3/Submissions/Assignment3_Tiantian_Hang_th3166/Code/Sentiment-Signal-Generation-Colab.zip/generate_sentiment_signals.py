#!/usr/bin/env python3
"""
Generate Sentiment Signals
Only runs news_fetcher + sentiment_agent to generate sentiment signals
Output: sentiment_signals.csv
"""

import os
import sys
import pandas as pd
import numpy as np
from datetime import datetime
from tqdm import tqdm
from dotenv import load_dotenv
import json

# Load environment variables
load_dotenv()

# Add project root to path
sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))

from news_fetcher.data_fetcher import NewsDataFetcher
from signal_generator.sentiment_agent import SentimentAgent


def load_selected_stocks(data_dir=None, stock_selected_file=None):
    """Load selected stocks from stock selection results
    
    Supports two formats:
    1. Standard format with headers: gvkey, trade_date, predicted_return
    2. Headerless format: gvkey, predicted_return, trade_date (columns 0, 1, 2)
    
    Args:
        data_dir: Directory containing stock_selected.csv (optional)
        stock_selected_file: Full path to stock_selected.csv (optional, takes precedence)
    """
    def _load_csv_file(file_path):
        """Helper function to load and parse CSV file"""
        # First, try reading with default behavior (headers if present)
        df = pd.read_csv(file_path)
        
        # Check if file has headers by checking if 'trade_date' column exists
        if 'trade_date' in df.columns:
            # Standard format with headers
            df['trade_date'] = pd.to_datetime(df['trade_date'])
            return df
        
        # If 'trade_date' not found, check if column names look like data (numeric)
        # If so, re-read without headers
        try:
            # Check if first column name can be converted to a number (likely data, not header)
            float(df.columns[0])
            # Column names look like data, re-read without headers
            df = pd.read_csv(file_path, header=None)
        except (ValueError, TypeError):
            # Column names are not numeric, they might be actual headers but different format
            pass
        
        # Now handle headerless format: gvkey, predicted_return, trade_date
        if len(df.columns) >= 3:
            # Rename columns based on expected format
            df.columns = ['gvkey', 'predicted_return', 'trade_date'] + list(df.columns[3:])
            # Convert date format from "2025/3/1" to datetime
            df['trade_date'] = pd.to_datetime(df['trade_date'], format='%Y/%m/%d', errors='coerce')
            # If format fails, try other common formats
            if df['trade_date'].isna().any():
                df['trade_date'] = pd.to_datetime(df['trade_date'], errors='coerce')
            print(f"  Detected headerless format: gvkey, predicted_return, trade_date")
            return df
        else:
            raise ValueError(
                f"CSV file must have either headers (gvkey, trade_date, ...) or "
                f"3+ columns without headers. Found {len(df.columns)} columns: {df.columns.tolist()}"
            )
    
    # If full path is provided, use it
    if stock_selected_file:
        if os.path.exists(stock_selected_file):
            print(f"Loading stock_selected.csv from: {stock_selected_file}")
            return _load_csv_file(stock_selected_file)
        else:
            raise FileNotFoundError(f"stock_selected.csv not found at {stock_selected_file}")
    
    # Otherwise, try data_dir
    if data_dir:
        stock_selected_file = os.path.join(data_dir, "stock_selected.csv")
        if os.path.exists(stock_selected_file):
            print(f"Loading stock_selected.csv from: {stock_selected_file}")
            return _load_csv_file(stock_selected_file)
    
    # Try common locations
    common_paths = [
        '/content/stock_selected.csv',
        'stock_selected.csv',
        'data_processor/outputs/stock_selected.csv',
        '../data_processor/outputs/stock_selected.csv',
    ]
    
    for path in common_paths:
        if os.path.exists(path):
            print(f"Found stock_selected.csv at: {path}")
            return _load_csv_file(path)
    
    # If not found, raise error
    error_msg = f"stock_selected.csv not found. Tried:\n"
    if stock_selected_file:
        error_msg += f"  - {stock_selected_file}\n"
    if data_dir:
        error_msg += f"  - {os.path.join(data_dir, 'stock_selected.csv')}\n"
    error_msg += "  - " + "\n  - ".join(common_paths)
    raise FileNotFoundError(error_msg)


def build_gvkey_to_ticker_map(price_file_path):
    """Build mapping from gvkey to ticker"""
    print(f"Building gvkey to ticker mapping from {price_file_path}...")
    fetcher = NewsDataFetcher()
    mapping = fetcher.build_gvkey_to_ticker_map(price_data_path=price_file_path)
    print(f"✓ Built mapping: {len(mapping)} stocks")
    return mapping


def generate_sentiment_signals(
    selected_stocks,
    gvkey_to_ticker,
    sentiment_agent,
    news_fetcher,
    output_file,
    start_date=None,
    end_date=None,
    max_stocks=None,
    resume=True,
    save_to_drive=False
):
    """
    Generate sentiment signals for selected stocks
    
    Args:
        selected_stocks: DataFrame with selected stocks
        gvkey_to_ticker: dict mapping gvkey to ticker
        sentiment_agent: SentimentAgent instance
        news_fetcher: NewsDataFetcher instance
        output_file: Path to output CSV file
        start_date: Start date filter (optional)
        end_date: End date filter (optional)
        max_stocks: Maximum number of stocks to process (for testing)
        resume: If True, resume from existing file
    """
    # Filter by date if specified
    if start_date:
        selected_stocks = selected_stocks[selected_stocks['trade_date'] >= pd.to_datetime(start_date)]
    if end_date:
        selected_stocks = selected_stocks[selected_stocks['trade_date'] <= pd.to_datetime(end_date)]
    
    # Limit stocks for testing
    if max_stocks:
        unique_gvkeys = selected_stocks['gvkey'].unique()[:max_stocks]
        selected_stocks = selected_stocks[selected_stocks['gvkey'].isin(unique_gvkeys)]
        print(f"⚠️  TEST MODE: Limited to {max_stocks} stocks")
    
    # Load existing results if resuming
    existing_results = {}
    if resume and os.path.exists(output_file):
        print(f"Loading existing results from {output_file}...")
        try:
            existing_df = pd.read_csv(output_file)
            existing_df['trade_date'] = pd.to_datetime(existing_df['trade_date'])
            for _, row in existing_df.iterrows():
                key = (row['gvkey'], row['trade_date'])
                existing_results[key] = row.to_dict()
            print(f"  Loaded {len(existing_results)} existing results")
        except Exception as e:
            print(f"  Warning: Could not load existing results: {e}")
    
    # Group by trade_date and gvkey
    grouped = selected_stocks.groupby(['trade_date', 'gvkey'])
    total_combinations = len(grouped)
    
    print(f"\nGenerating sentiment signals...")
    print(f"  Total combinations: {total_combinations}")
    print(f"  Date range: {selected_stocks['trade_date'].min()} to {selected_stocks['trade_date'].max()}")
    print(f"  Unique stocks: {selected_stocks['gvkey'].nunique()}")
    
    results = []
    processed = 0
    skipped = 0
    errors = 0
    
    # Create progress bar
    pbar = tqdm(total=total_combinations, desc="Processing", unit="stock-date")
    
    for (trade_date, gvkey), group in grouped:
        # Check if already processed
        key = (gvkey, trade_date)
        if key in existing_results:
            results.append(existing_results[key])
            skipped += 1
            pbar.update(1)
            continue
        
        # Get ticker
        ticker = gvkey_to_ticker.get(gvkey)
        if ticker is None:
            print(f"\nWarning: No ticker found for gvkey {gvkey}, skipping...")
            errors += 1
            pbar.update(1)
            continue
        
        # Convert trade_date to string
        trade_date_str = trade_date.strftime('%Y-%m-%d')
        
        try:
            pbar.set_description(f"Processing {ticker} ({gvkey}) on {trade_date_str}")
            
            # Get news data
            news_data = news_fetcher.fetch_all_data(ticker, trade_date_str, n_weeks=3)
            
            # Generate sentiment signal
            sentiment_result = sentiment_agent.analyze(
                news_data=news_data,
                symbol=ticker,
                date=trade_date_str,
                n_weeks=3
            )
            
            # Prepare result
            result = {
                'trade_date': trade_date_str,
                'gvkey': gvkey,
                'ticker': ticker,
                'sentiment_signal': sentiment_result.get('signal', 0),
                'sentiment_confidence': sentiment_result.get('confidence', 0.5),
                'predicted_return': sentiment_result.get('predicted_return', 0.0),
                'positive_count': sentiment_result.get('positive_count', 0),
                'negative_count': sentiment_result.get('negative_count', 0),
                'raw_output': sentiment_result.get('raw_output', '')[:500]  # Truncate for CSV
            }
            
            results.append(result)
            processed += 1
            
            # Save intermediate results every 10 records
            if len(results) % 10 == 0:
                df_results = pd.DataFrame(results)
                df_results.to_csv(output_file, index=False)
        
        except Exception as e:
            import traceback
            error_msg = str(e)
            # Print full traceback for debugging
            print(f"\nError processing {ticker} (gvkey: {gvkey}) on {trade_date_str}: {error_msg}")
            # Only print traceback for non-ValueError exceptions (ValueError is usually expected)
            if not isinstance(e, ValueError):
                traceback.print_exc()
            errors += 1
        
        pbar.update(1)
    
    pbar.close()
    
    # Save final results (even if empty)
    if results:
        df_results = pd.DataFrame(results)
        df_results.to_csv(output_file, index=False)
        print(f"\n✓ Saved {len(results)} sentiment signals to {output_file}")
    else:
        # Create empty file with headers if no results
        columns = ['trade_date', 'gvkey', 'ticker', 'sentiment_signal', 'sentiment_confidence', 
                   'predicted_return', 'positive_count', 'negative_count', 'raw_output']
        df_empty = pd.DataFrame(columns=columns)
        df_empty.to_csv(output_file, index=False)
        print(f"\n⚠️  No results generated. Created empty file: {output_file}")
        print("   Check error messages above for details.")
    
    # Optionally save to Google Drive if in Colab environment
    if results:  # Only save to Drive if we have results
        try:
            import sys
            if 'google.colab' in sys.modules:
                # Check if user wants to save to Drive (from env var or function parameter)
                save_to_drive_flag = save_to_drive or os.environ.get('SAVE_TO_DRIVE', 'false').lower() == 'true'
                if save_to_drive_flag:
                    try:
                        from google.colab import drive
                        import shutil
                        from datetime import datetime
                        
                        # Mount Drive
                        drive.mount('/content/drive', force_remount=False)
                        
                        # Create Drive directory
                        drive_base = '/content/drive/MyDrive/Colab_Results'
                        timestamp = datetime.now().strftime('%Y%m%d_%H%M%S')
                        drive_dir = os.path.join(drive_base, f'sentiment_signals_{timestamp}')
                        os.makedirs(drive_dir, exist_ok=True)
                        
                        # Copy file to Drive
                        filename = os.path.basename(output_file)
                        drive_path = os.path.join(drive_dir, filename)
                        shutil.copy(output_file, drive_path)
                        
                        print(f"✓ Also saved to Google Drive: {drive_path}")
                    except Exception as e:
                        print(f"⚠️  Warning: Could not save to Google Drive: {e}")
                        print("   You can manually save using the code in COLAB_DOWNLOAD_GUIDE.md")
        except ImportError:
            pass  # Not in Colab environment
    
    print(f"\nSummary:")
    print(f"  Processed: {processed}")
    print(f"  Skipped (already exists): {skipped}")
    print(f"  Errors: {errors}")
    print(f"  Total: {len(results)}")
    
    return results


def main():
    """Main function"""
    import argparse
    
    parser = argparse.ArgumentParser(
        description='Generate Sentiment Signals from News Data',
        formatter_class=argparse.RawDescriptionHelpFormatter
    )
    
    parser.add_argument(
        '--data_dir',
        type=str,
        default=None,
        help='Directory with stock_selected.csv (optional if using --stock_selected_file)'
    )
    
    parser.add_argument(
        '--stock_selected_file',
        type=str,
        default=None,
        help='Full path to stock_selected.csv (e.g., /content/stock_selected.csv). Takes precedence over --data_dir'
    )
    
    parser.add_argument(
        '--price_file',
        type=str,
        default=None,
        help='Path to price data file for gvkey mapping (e.g., /content/sp500_tickers_daily_price.csv)'
    )
    
    parser.add_argument(
        '--output_file',
        type=str,
        default=None,
        help='Output CSV file path (default: sentiment_signals.csv in current directory)'
    )
    
    parser.add_argument(
        '--start_date',
        type=str,
        default=None,
        help='Start date filter (YYYY-MM-DD)'
    )
    
    parser.add_argument(
        '--end_date',
        type=str,
        default=None,
        help='End date filter (YYYY-MM-DD)'
    )
    
    parser.add_argument(
        '--max_stocks',
        type=int,
        default=None,
        help='Maximum number of stocks to process (for testing)'
    )
    
    parser.add_argument(
        '--no_resume',
        action='store_true',
        help='Do not resume from existing file'
    )
    
    parser.add_argument(
        '--save_to_drive',
        action='store_true',
        help='Save results to Google Drive (Colab only, requires SAVE_TO_DRIVE env var or this flag)'
    )
    
    args = parser.parse_args()
    
    print("=" * 80)
    print("Generate Sentiment Signals")
    print("=" * 80)
    # Auto-detect price file if not provided
    if not args.price_file:
        common_price_paths = [
            '/content/sp500_tickers_daily_price.csv',
            'sp500_tickers_daily_price.csv',
            '../dec data/sp500_tickers_daily_price.csv',
            'dec data/sp500_tickers_daily_price.csv',
        ]
        for path in common_price_paths:
            if os.path.exists(path):
                args.price_file = path
                print(f"Auto-detected price file: {path}")
                break
        
        if not args.price_file:
            raise FileNotFoundError(
                "Price file not found. Please specify --price_file. "
                "Tried: " + ", ".join(common_price_paths)
            )
    
    # Set default output file if not provided
    if not args.output_file:
        args.output_file = 'sentiment_signals.csv'
        print(f"Using default output file: {args.output_file}")
    
    print(f"Stock selected file: {args.stock_selected_file or args.data_dir or 'auto-detect'}")
    print(f"Price file: {args.price_file}")
    print(f"Output file: {args.output_file}")
    if args.start_date:
        print(f"Start date: {args.start_date}")
    if args.end_date:
        print(f"End date: {args.end_date}")
    if args.max_stocks:
        print(f"Max stocks: {args.max_stocks}")
    print("=" * 80)
    
    try:
        # Load selected stocks
        print("\n[1/4] Loading selected stocks...")
        selected_stocks = load_selected_stocks(
            data_dir=args.data_dir,
            stock_selected_file=args.stock_selected_file
        )
        print(f"  Loaded {len(selected_stocks)} records")
        print(f"  Date range: {selected_stocks['trade_date'].min()} to {selected_stocks['trade_date'].max()}")
        print(f"  Unique stocks: {selected_stocks['gvkey'].nunique()}")
        
        # Build gvkey to ticker mapping
        print("\n[2/4] Building gvkey to ticker mapping...")
        gvkey_to_ticker = build_gvkey_to_ticker_map(args.price_file)
        
        # Initialize sentiment agent
        print("\n[3/4] Initializing sentiment agent (this may take a while)...")
        sentiment_agent = SentimentAgent()
        print("  ✓ Sentiment agent initialized")
        
        # Initialize news fetcher (with local price data if available)
        news_fetcher = NewsDataFetcher(price_data_path=args.price_file)
        print("  ✓ News fetcher initialized")
        
        # Generate sentiment signals
        print("\n[4/4] Generating sentiment signals...")
        results = generate_sentiment_signals(
            selected_stocks=selected_stocks,
            gvkey_to_ticker=gvkey_to_ticker,
            sentiment_agent=sentiment_agent,
            news_fetcher=news_fetcher,
            output_file=args.output_file,
            start_date=args.start_date,
            end_date=args.end_date,
            max_stocks=args.max_stocks,
            resume=not args.no_resume,
            save_to_drive=args.save_to_drive
        )
        
        print("\n" + "=" * 80)
        print("✓ Sentiment signal generation complete!")
        print(f"  Output: {args.output_file}")
        print("=" * 80)
        
        return 0
        
    except Exception as e:
        print(f"\n✗ Error: {e}")
        import traceback
        traceback.print_exc()
        return 1


if __name__ == "__main__":
    sys.exit(main())


