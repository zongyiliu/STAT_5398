#!/usr/bin/env python3
"""
Quick test script for Colab
Tests sentiment signal generation with minimal data (5 stocks, 1 month)
"""

import os
import sys

def test_sentiment_generation():
    """Quick test of sentiment signal generation"""
    
    print("=" * 80)
    print("Sentiment Signal Generation - Quick Test")
    print("=" * 80)
    print()
    
    # Check files
    print("[1/5] Checking required files...")
    required_files = {
        'stock_selected.csv': '/content/stock_selected.csv',
        'price_file': '/content/sp500_tickers_daily_price.csv',
    }
    
    missing_files = []
    for name, path in required_files.items():
        if os.path.exists(path):
            size = os.path.getsize(path) / 1024 / 1024
            print(f"  ✓ {name}: {path} ({size:.2f} MB)")
        else:
            print(f"  ✗ {name}: {path} (not found)")
            missing_files.append(name)
    
    if missing_files:
        print(f"\n⚠️  Missing files: {', '.join(missing_files)}")
        print("   Please upload these files to /content/ directory")
        return False
    
    # Check API keys
    print("\n[2/5] Checking API keys...")
    finnhub_key = os.environ.get('FINNHUB_API_KEY') or os.environ.get('FINNHUB_KEY')
    hf_token = os.environ.get('HF_TOKEN')
    
    if finnhub_key:
        print(f"  ✓ FINNHUB_API_KEY: {'*' * 10}...")
    else:
        print("  ✗ FINNHUB_API_KEY: not set")
    
    if hf_token:
        print(f"  ✓ HF_TOKEN: {'*' * 10}...")
    else:
        print("  ✗ HF_TOKEN: not set")
    
    if not finnhub_key or not hf_token:
        print("\n⚠️  Please set API keys:")
        print("   os.environ['FINNHUB_API_KEY'] = 'your_key'")
        print("   os.environ['HF_TOKEN'] = 'your_token'")
        return False
    
    # Check HuggingFace access
    print("\n[2.5/5] Checking HuggingFace access...")
    try:
        from huggingface_hub import login, HfApi
        
        # Try to login
        try:
            login(token=hf_token, add_to_git_credential=False)
            print("  ✓ Logged in to HuggingFace")
        except Exception as e:
            print(f"  ⚠️  Login warning: {e}")
        
        # Check model access
        api = HfApi()
        try:
            model_info = api.model_info(
                'meta-llama/Llama-2-7b-chat-hf',
                token=hf_token
            )
            print("  ✓ Can access meta-llama/Llama-2-7b-chat-hf")
        except Exception as e:
            print(f"  ✗ Cannot access model: {e}")
            print("\n⚠️  Model access denied!")
            print("   Please:")
            print("   1. Visit https://huggingface.co/meta-llama/Llama-2-7b-chat-hf")
            print("   2. Click 'Request access' to apply for access")
            print("   3. Wait for approval (usually a few hours)")
            print("   4. Run this test again")
            print("\n   See HUGGINGFACE_ACCESS_FIX.md for detailed instructions")
            return False
    except ImportError:
        print("  ⚠️  huggingface_hub not installed, skipping access check")
        print("     Run: !pip install huggingface_hub")
    except Exception as e:
        print(f"  ⚠️  Error checking access: {e}")
        print("     Continuing anyway...")
    
    # Check GPU
    print("\n[3/5] Checking GPU...")
    try:
        import torch
        if torch.cuda.is_available():
            print(f"  ✓ GPU available: {torch.cuda.get_device_name(0)}")
            print(f"    Memory: {torch.cuda.get_device_properties(0).total_memory / 1e9:.2f} GB")
        else:
            print("  ⚠️  No GPU detected. Model loading will be slow.")
            print("     Please enable GPU: Runtime → Change runtime type → GPU")
    except ImportError:
        print("  ⚠️  PyTorch not installed yet")
    
    # Check dependencies
    print("\n[4/5] Checking dependencies...")
    required_packages = [
        'pandas', 'numpy', 'tqdm', 'dotenv', 
        'finnhub', 'yfinance', 'transformers', 'peft', 'torch'
    ]
    
    missing_packages = []
    for package in required_packages:
        try:
            if package == 'dotenv':
                __import__('dotenv')
            elif package == 'finnhub':
                __import__('finnhub')
            else:
                __import__(package)
            print(f"  ✓ {package}")
        except ImportError:
            print(f"  ✗ {package} (not installed)")
            missing_packages.append(package)
    
    if missing_packages:
        print(f"\n⚠️  Missing packages: {', '.join(missing_packages)}")
        print("   Run: !pip install -r requirements.txt")
        return False
    
    # Run test
    print("\n[5/5] Running test (5 stocks, 1 month)...")
    print("=" * 80)
    
    try:
        # Import and run
        from generate_sentiment_signals import main
        import sys
        
        # Set test arguments
        sys.argv = [
            'test_sentiment_colab.py',
            '--stock_selected_file', '/content/stock_selected.csv',
            '--price_file', '/content/sp500_tickers_daily_price.csv',
            '--output_file', 'test_sentiment_signals.csv',
            '--max_stocks', '5',
            '--start_date', '2024-12-01',
            '--end_date', '2024-12-31',
        ]
        
        main()
        
        print("\n" + "=" * 80)
        print("✓ Test completed successfully!")
        print("=" * 80)
        
        # Check output
        if os.path.exists('test_sentiment_signals.csv'):
            size = os.path.getsize('test_sentiment_signals.csv')
            print(f"\n✓ Output file created: test_sentiment_signals.csv ({size} bytes)")
            return True
        else:
            print("\n⚠️  Output file not found")
            return False
            
    except Exception as e:
        print(f"\n✗ Test failed: {e}")
        import traceback
        traceback.print_exc()
        return False


if __name__ == "__main__":
    success = test_sentiment_generation()
    sys.exit(0 if success else 1)

