# 修复 "Tensor on device cpu is not on the expected device meta!" 错误

## 🔍 问题诊断

### 错误信息
```
RuntimeError: Tensor on device cpu is not on the expected device meta!
```

### 根本原因

1. **设备不匹配**：
   - 模型使用了 `device_map="auto"`，当没有 GPU 或 GPU 内存不足时
   - `accelerate` 库会将部分参数卸载到 `meta` 设备（PyTorch 的元设备）
   - `meta` 设备用于模型初始化时节省内存，**不能用于实际计算**
   - 输入张量在 CPU 上，但模型参数在 `meta` 设备上，导致设备不匹配

2. **警告信息**：
   ```
   WARNING:accelerate.big_modeling:Some parameters are on the meta device 
   because they were offloaded to the cpu and disk.
   ```
   这表明模型参数被卸载到了 `meta` 设备。

3. **是否因为没有 GPU？**
   - **部分相关**：如果没有 GPU，`device_map="auto"` 可能会使用 `meta` 设备
   - **但主要问题**：即使有 GPU，如果 GPU 内存不足，也会出现同样的问题

---

## ✅ 解决方案

### 修复内容

已修改 `signal_generator/sentiment_agent.py`：

1. **检测设备**：
   - 自动检测是否有 GPU
   - 如果有 GPU，使用 `device_map="auto"`
   - 如果没有 GPU，使用 `device_map="cpu"`（避免使用 `meta` 设备）

2. **确保模型在正确设备上**：
   - 如果使用 CPU，显式将模型移动到 CPU
   - 避免模型参数留在 `meta` 设备上

3. **修复输入张量设备**：
   - 正确处理 `device_map` 的情况
   - 找到第一个非 `meta` 设备，将输入张量移动到该设备

---

## 🔧 修复后的代码

### 关键修改

```python
# 检测设备
if torch.cuda.is_available():
    device = "cuda"
    device_map = "auto"
    print(f"✓ GPU detected: {torch.cuda.get_device_name(0)}")
else:
    device = "cpu"
    device_map = "cpu"  # 使用 CPU 显式避免 meta 设备
    print("⚠️  No GPU detected. Using CPU (this will be slow)")

# 加载模型
self.base_model = AutoModelForCausalLM.from_pretrained(
    base_model_path,
    token=self.hf_token,
    trust_remote_code=True,
    device_map=device_map,
    torch_dtype=torch.float16 if device == "cuda" else torch.float32,
)

# 确保模型在正确设备上（不是 meta）
if device_map == "cpu":
    self.base_model = self.base_model.to(device)
```

---

## 📋 使用建议

### 1. 如果有 GPU（推荐）

在 Colab 中：
1. **启用 GPU**：`Runtime → Change runtime type → GPU`
2. 运行代码，会自动使用 GPU

### 2. 如果没有 GPU

代码会自动检测并使用 CPU：
- 会显示警告：`⚠️  No GPU detected. Using CPU (this will be slow)`
- 模型会显式加载到 CPU，避免 `meta` 设备问题
- **注意**：CPU 推理会非常慢（每个股票可能需要 20+ 分钟）

### 3. 如果 GPU 内存不足

如果遇到 GPU 内存不足：
- 可以考虑使用更小的模型（如 Llama 3.1 8B）
- 或者使用 `offload_folder` 参数将部分参数卸载到磁盘

---

## 🧪 测试

修复后，运行测试：

```python
!python test_sentiment_colab.py
```

应该看到：
- ✅ 如果 GPU 可用：`✓ GPU detected: [GPU名称]`
- ✅ 如果没有 GPU：`⚠️  No GPU detected. Using CPU (this will be slow)`
- ✅ 不再出现 `meta device` 错误

---

## 📝 相关文件

- `signal_generator/sentiment_agent.py` - 已修复
- `COLAB_FIX_DEVICE_META_ERROR.md` - 本文档

---

## 🎯 总结

**问题原因**：
- `device_map="auto"` 在没有 GPU 或内存不足时使用 `meta` 设备
- `meta` 设备不能用于实际计算
- 输入张量和模型参数设备不匹配

**解决方案**：
- 检测设备（GPU/CPU）
- 如果没有 GPU，使用 `device_map="cpu"` 显式避免 `meta` 设备
- 确保模型和输入张量在同一设备上

**建议**：
- **强烈建议使用 GPU**：CPU 推理会非常慢
- 在 Colab 中启用 GPU：`Runtime → Change runtime type → GPU`

