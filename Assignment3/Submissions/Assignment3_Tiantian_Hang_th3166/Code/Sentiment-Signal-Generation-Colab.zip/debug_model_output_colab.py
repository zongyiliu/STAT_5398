#!/usr/bin/env python3
"""
Colab 调试脚本：检查模型是否正确生成输出
用于诊断 sentiment signal 生成问题
在 Colab 中直接运行此脚本
"""

import os
import sys
import pandas as pd

# 在 Colab 中，路径通常是 /content/
if os.path.exists('/content'):
    sys.path.insert(0, '/content')
    os.chdir('/content')

# Load environment variables (if .env exists)
try:
    from dotenv import load_dotenv
    load_dotenv()
except:
    pass

# 设置环境变量（如果还没有设置）
if not os.environ.get('HF_TOKEN'):
    print("⚠️  警告: HF_TOKEN 未设置")
    print("   请在 Colab 中运行: os.environ['HF_TOKEN'] = 'your_token'")

if not os.environ.get('FINNHUB_API_KEY'):
    print("⚠️  警告: FINNHUB_API_KEY 未设置（可选，用于获取新闻）")

try:
    from signal_generator.sentiment_agent import SentimentAgent
    from news_fetcher.data_fetcher import NewsDataFetcher
    from news_fetcher.prompt_builder import PromptBuilder
except ImportError as e:
    print(f"❌ 导入错误: {e}")
    print("   请确保已解压 ZIP 文件到 /content/")
    sys.exit(1)


def debug_model_output(symbol="AAPL", date="2024-12-01", n_weeks=3):
    """
    调试模型输出生成过程
    
    Args:
        symbol: 股票代码
        date: 交易日期
        n_weeks: 回溯周数
    """
    print("=" * 80)
    print("模型输出调试工具 (Colab)")
    print("=" * 80)
    print(f"股票代码: {symbol}")
    print(f"日期: {date}")
    print(f"回溯周数: {n_weeks}")
    print("=" * 80)
    
    try:
        # 1. 初始化 SentimentAgent
        print("\n[1/7] 初始化 SentimentAgent...")
        print("  ⚠️  这可能需要几分钟时间（首次运行需要下载模型）...")
        sentiment_agent = SentimentAgent()
        print("  ✓ SentimentAgent 初始化成功")
        print(f"  - 设备: {sentiment_agent.device}")
        print(f"  - 模型类型: {type(sentiment_agent.model).__name__}")
        
        # 2. 获取新闻数据
        print("\n[2/7] 获取新闻数据...")
        news_fetcher = NewsDataFetcher()
        news_data = news_fetcher.fetch_all_data(symbol, date, n_weeks)
        print(f"  ✓ 获取到 {len(news_data)} 条记录")
        if len(news_data) > 0:
            print(f"  - 数据列: {list(news_data.columns)}")
            # Check for date columns (could be 'Start Date', 'End Date', or 'datetime')
            if 'Start Date' in news_data.columns:
                print(f"  - 日期范围: {news_data['Start Date'].min()} 到 {news_data['End Date'].max()}")
            elif 'datetime' in news_data.columns:
                print(f"  - 新闻日期范围: {news_data['datetime'].min()} 到 {news_data['datetime'].max()}")
            # Check for News column
            if 'News' in news_data.columns:
                total_news = 0
                for idx, row in news_data.iterrows():
                    if pd.notna(row.get('News')) and row.get('News'):
                        try:
                            import json
                            news_list = json.loads(row['News']) if isinstance(row['News'], str) else row['News']
                            total_news += len(news_list) if isinstance(news_list, list) else 0
                        except:
                            pass
                print(f"  - 总新闻数: {total_news}")
        else:
            print("  ⚠️  警告: 没有获取到新闻数据")
        
        # 3. 构建 Prompt
        print("\n[3/7] 构建 Prompt...")
        prompt_builder = PromptBuilder()
        info, prompt = prompt_builder.get_all_prompts_online(
            symbol, news_data, date, with_basics=True
        )
        
        # 格式化 prompt（根据模型类型）
        if hasattr(sentiment_agent, 'B_INST'):
            # Llama 2 格式
            formatted_prompt = (
                sentiment_agent.B_INST + sentiment_agent.B_SYS + 
                sentiment_agent.SYSTEM_PROMPT + sentiment_agent.E_SYS + 
                prompt + sentiment_agent.E_INST
            )
        else:
            # Llama 3.1 格式（使用 format_prompt 方法）
            formatted_prompt = sentiment_agent.format_prompt(
                sentiment_agent.SYSTEM_PROMPT, prompt
            )
        
        print(f"  ✓ Prompt 构建成功")
        print(f"  - Prompt 长度: {len(formatted_prompt)} 字符")
        print(f"  - Prompt 前 200 字符:")
        print(f"    {formatted_prompt[:200]}...")
        
        # 4. Tokenize 输入
        print("\n[4/7] Tokenize 输入...")
        inputs = sentiment_agent.tokenizer(formatted_prompt, return_tensors='pt')
        
        # 移动到正确的设备
        if hasattr(sentiment_agent.model, 'device'):
            target_device = sentiment_agent.model.device
        elif hasattr(sentiment_agent.model, 'hf_device_map'):
            device_map = sentiment_agent.model.hf_device_map
            target_device = None
            for layer_device in device_map.values():
                if layer_device != 'meta' and layer_device is not None:
                    target_device = layer_device
                    break
            if target_device is None:
                target_device = sentiment_agent.device
        else:
            target_device = sentiment_agent.device
        
        inputs = {key: value.to(target_device) for key, value in inputs.items()}
        
        print(f"  ✓ 输入 tokenize 成功")
        print(f"  - 输入设备: {target_device}")
        print(f"  - 输入 token 数量: {inputs['input_ids'].shape[1]}")
        
        # 5. 生成模型输出
        print("\n[5/7] 生成模型输出...")
        print("  ⚠️  这可能需要几分钟时间，请耐心等待...")
        print("  ⚠️  如果使用 CPU，可能需要 10-20 分钟！")
        
        import torch
        with torch.no_grad():
            res = sentiment_agent.model.generate(
                **inputs,
                max_length=4096,
                do_sample=True,
                eos_token_id=sentiment_agent.tokenizer.eos_token_id,
                use_cache=True,
                temperature=0.7,
                top_p=0.9
            )
        
        print(f"  ✓ 模型生成完成")
        print(f"  - 输出 token 数量: {res[0].shape[0]}")
        print(f"  - 输入 token 数量: {inputs['input_ids'].shape[1]}")
        new_tokens = res[0].shape[0] - inputs['input_ids'].shape[1]
        print(f"  - 新生成 token 数量: {new_tokens}")
        
        # 关键检查：是否生成了新内容
        if new_tokens > 0:
            print(f"  ✅ 模型生成了新内容！")
        else:
            print(f"  ❌ 警告: 模型没有生成新内容！")
            print(f"     这可能意味着模型没有正确生成输出")
        
        # 6. 解码输出
        print("\n[6/7] 解码和解析输出...")
        output = sentiment_agent.tokenizer.decode(res[0], skip_special_tokens=True)
        
        print(f"  ✓ 输出解码成功")
        print(f"  - 输出总长度: {len(output)} 字符")
        print(f"  - 输入 prompt 长度: {len(formatted_prompt)} 字符")
        model_generated_length = len(output) - len(formatted_prompt)
        print(f"  - 模型生成部分长度: {model_generated_length} 字符")
        
        # 关键检查：输出长度是否大于 prompt 长度
        if len(output) > len(formatted_prompt):
            model_generated = output[len(formatted_prompt):].strip()
            print(f"\n  ✅ 模型生成了新内容 ({len(model_generated)} 字符)")
            print(f"  - 前 300 字符:")
            preview = model_generated[:300]
            for line in preview.split('\n'):
                print(f"    {line}")
            if len(model_generated) > 300:
                print(f"    ... (还有 {len(model_generated) - 300} 字符)")
        else:
            print(f"\n  ❌ 警告: 模型没有生成新内容！")
            print(f"  - 输出长度: {len(output)}")
            print(f"  - Prompt 长度: {len(formatted_prompt)}")
            print(f"  - 这可能意味着模型没有正确生成输出")
        
        # 7. 解析输出
        print("\n[7/7] 解析输出...")
        result = sentiment_agent._parse_output(output, symbol)
        
        print(f"  ✓ 输出解析完成")
        print(f"  - Signal: {result['signal']} ({'BUY' if result['signal'] == 1 else 'SELL' if result['signal'] == -1 else 'HOLD'})")
        print(f"  - Confidence: {result['confidence']:.2f}")
        print(f"  - Predicted Return: {result['predicted_return']:.4f} ({result['predicted_return']*100:.2f}%)")
        print(f"  - Positive Count: {result['positive_count']}")
        print(f"  - Negative Count: {result['negative_count']}")
        
        # 检查是否找到了 Prediction
        import re
        # 使用与 _parse_output 相同的正则表达式（支持范围格式）
        prediction_match = re.search(
            r'Prediction:\s*(?:up|down)\s*(?:by)?\s*([\d.]+)(?:-([\d.]+))?%',
            output,
            re.IGNORECASE
        )
        
        if prediction_match:
            print(f"\n  ✅ 找到 Prediction 模式")
            print(f"  - 匹配内容: {prediction_match.group(0)}")
        else:
            print(f"\n  ⚠️  警告: 没有找到 Prediction 模式")
            print(f"  - 尝试查找 'Prediction' 关键词...")
            if 'prediction' in output.lower():
                # 找到包含 prediction 的行
                lines = output.split('\n')
                for i, line in enumerate(lines):
                    if 'prediction' in line.lower():
                        print(f"  - 找到包含 'prediction' 的行 {i+1}: {line[:100]}")
                        break
            else:
                print(f"  - 输出中完全没有 'prediction' 关键词")
        
        # 检查是否找到了 Positive Developments 和 Potential Concerns
        positive_matches = re.findall(r'\[Positive Developments\]:', output, re.IGNORECASE)
        concern_matches = re.findall(r'\[Potential Concerns\]:', output, re.IGNORECASE)
        
        print(f"\n  - Positive Developments 匹配: {len(positive_matches)} 次")
        print(f"  - Potential Concerns 匹配: {len(concern_matches)} 次")
        
        # 保存完整输出到文件
        output_file = f"debug_output_{symbol}_{date}.txt"
        with open(output_file, 'w', encoding='utf-8') as f:
            f.write("=" * 80 + "\n")
            f.write("完整模型输出\n")
            f.write("=" * 80 + "\n\n")
            f.write("输入 Prompt:\n")
            f.write("-" * 80 + "\n")
            f.write(formatted_prompt)
            f.write("\n\n" + "=" * 80 + "\n\n")
            f.write("完整输出 (包含 prompt):\n")
            f.write("-" * 80 + "\n")
            f.write(output)
            f.write("\n\n" + "=" * 80 + "\n\n")
            if len(output) > len(formatted_prompt):
                f.write("模型生成的部分 (不包含 prompt):\n")
                f.write("-" * 80 + "\n")
                f.write(output[len(formatted_prompt):].strip())
        
        print(f"\n  ✓ 完整输出已保存到: {output_file}")
        
        # 总结
        print("\n" + "=" * 80)
        print("调试总结")
        print("=" * 80)
        
        issues = []
        if len(output) <= len(formatted_prompt):
            issues.append("❌ 模型没有生成新内容（输出长度 <= prompt 长度）")
        if new_tokens <= 0:
            issues.append("❌ 模型没有生成新 token（新生成 token 数量 <= 0）")
        if not prediction_match:
            issues.append("⚠️  没有找到 Prediction 模式")
        if result['signal'] == 0 and result['confidence'] == 0.5:
            issues.append("⚠️  使用了默认值（signal=0, confidence=0.5）")
        if len(news_data) == 0:
            issues.append("⚠️  没有获取到新闻数据")
        
        if issues:
            print("\n发现的问题:")
            for issue in issues:
                print(f"  {issue}")
        else:
            print("\n✅ 没有发现明显问题")
            print("  模型似乎正常工作！")
        
        print("\n" + "=" * 80)
        
        return {
            'output': output,
            'model_generated': output[len(formatted_prompt):].strip() if len(output) > len(formatted_prompt) else "",
            'result': result,
            'prediction_found': prediction_match is not None,
            'output_file': output_file,
            'new_tokens': new_tokens,
            'prompt_length': len(formatted_prompt),
            'output_length': len(output)
        }
        
    except Exception as e:
        print(f"\n❌ 错误: {e}")
        import traceback
        traceback.print_exc()
        return None


if __name__ == "__main__":
    # 在 Colab 中可以直接运行，也可以传入参数
    import sys
    
    if len(sys.argv) > 1:
        # 从命令行参数获取
        symbol = sys.argv[1] if len(sys.argv) > 1 else "AAPL"
        date = sys.argv[2] if len(sys.argv) > 2 else "2024-12-01"
        n_weeks = int(sys.argv[3]) if len(sys.argv) > 3 else 3
    else:
        # 使用默认值或从环境变量获取
        symbol = os.environ.get('DEBUG_SYMBOL', 'AAPL')
        date = os.environ.get('DEBUG_DATE', '2024-12-01')
        n_weeks = int(os.environ.get('DEBUG_N_WEEKS', '3'))
    
    print("\n" + "=" * 80)
    print("Colab 模型输出调试工具")
    print("=" * 80)
    print("\n使用方法:")
    print("  1. 直接运行: !python debug_model_output_colab.py")
    print("  2. 指定股票: !python debug_model_output_colab.py AAPL 2024-12-01")
    print("  3. 完整参数: !python debug_model_output_colab.py NBR 2024-12-01 3")
    print("\n" + "=" * 80 + "\n")
    
    debug_model_output(symbol, date, n_weeks)

