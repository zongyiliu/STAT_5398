# 情感信号生成指南

## 📋 思路确认

### ✅ 您的思路完全正确！

**分阶段实施的优势**:
1. ✅ **独立验证**: 可以单独测试每个组件
2. ✅ **易于调试**: 问题更容易定位
3. ✅ **灵活优化**: 可以基于实际数据优化融合策略
4. ✅ **资源利用**: 充分利用已有的技术分析结果

---

## 🎯 实施步骤

### 阶段 1: 生成情感信号（当前）

**脚本**: `generate_sentiment_signals.py`

**功能**:
- 只运行 `news_fetcher` + `sentiment_agent`
- 为选中的股票生成情感信号
- 输出 `sentiment_signals.csv`

**使用方法**:
```bash
# 完整运行
python generate_sentiment_signals.py

# 测试模式（少量股票）
python generate_sentiment_signals.py --max_stocks 5

# 指定日期范围
python generate_sentiment_signals.py \
    --start_date "2024-12-01" \
    --end_date "2025-11-30"
```

**输出文件格式**:
```csv
trade_date,gvkey,ticker,sentiment_signal,sentiment_confidence,predicted_return,positive_count,negative_count,raw_output
2024-12-01,1078,AAPL,1,0.85,0.05,3,1,"[Positive Developments]:..."
```

### 阶段 2: 融合信号并优化权重

**脚本**: `fuse_signals.py`

**功能**:
- 加载技术信号（从权重文件）
- 加载情感信号（从 CSV）
- 测试不同的权重组合
- 找到最优权重

**使用方法**:
```bash
python fuse_signals.py \
    --technical_file "data_processor/outputs/mean_weighted.xlsx" \
    --sentiment_file "data_processor/outputs/sentiment_signals.csv" \
    --weight_step 0.1
```

**输出**:
- `fusion_results.csv`: 所有权重组合的测试结果
- 控制台输出: 最优权重组合

### 阶段 3: 使用最优权重进行回测

**使用优化后的权重**:
```python
# 在 portfolio_manager 中使用最优权重
portfolio_manager = PortfolioManager(fusion_strategy='weighted')
# 使用从 fuse_signals.py 找到的最优权重
```

---

## 💡 优化建议

### 1. 情感信号生成优化

#### 批量处理
- 按交易日期分组
- 可以并行处理（注意 API 限制）
- 支持断点续传（`--resume` 选项）

#### 数据缓存
- 已处理的股票会跳过（如果使用 `--resume`）
- 中间结果每 10 条保存一次
- 避免重复计算

### 2. 融合策略优化

#### 网格搜索
```python
# 测试不同的权重组合
weight_combinations = [
    (0.3, 0.7),  # 30% sentiment, 70% technical
    (0.4, 0.6),
    (0.5, 0.5),
    (0.6, 0.4),
    (0.7, 0.3),  # 70% sentiment, 30% technical
]
```

#### 自适应权重
基于置信度动态调整：
```python
if sentiment_confidence > 0.8:
    w_sentiment = 0.8
elif technical_confidence > 0.8:
    w_technical = 0.8
```

#### 市场状态自适应
根据市场波动率调整：
```python
if volatility > 0.7:  # 高波动
    w_technical = 0.7  # 更信任技术分析
else:  # 低波动
    w_sentiment = 0.7  # 更信任新闻情感
```

### 3. 性能指标

优化时关注：
- **总收益率** (Total Return)
- **夏普比率** (Sharpe Ratio) - 风险调整收益
- **最大回撤** (Max Drawdown) - 风险控制
- **胜率** (Win Rate)
- **复合得分** (Composite Score)

---

## 📊 预期工作流程

```
1. 生成情感信号
   └─> sentiment_signals.csv

2. 融合信号并优化
   ├─> 加载技术信号 (mean_weighted.xlsx)
   ├─> 加载情感信号 (sentiment_signals.csv)
   ├─> 测试不同权重组合
   └─> 找到最优权重

3. 使用最优权重回测
   └─> 生成最终结果
```

---

## ⚠️ 注意事项

### 1. 时间对齐
- 确保情感信号使用的新闻在交易日期之前
- 避免未来信息泄露

### 2. 数据一致性
- 确保技术信号和情感信号使用相同的股票列表
- 确保日期范围一致

### 3. 计算资源
- 情感信号生成需要 GPU（FinGPT 模型）
- 建议在 Colab 上运行
- 可以分批处理

### 4. API 限制
- Finnhub API: 60 calls/minute
- 代码中已包含延迟和重试机制

---

## 🚀 快速开始

### 步骤 1: 生成情感信号（Colab）

```python
# 在 Colab 中运行
!python generate_sentiment_signals.py \
    --max_stocks 5 \
    --start_date "2024-12-01" \
    --end_date "2024-12-31"
```

### 步骤 2: 融合信号并优化

```python
# 在本地或 Colab 运行
!python fuse_signals.py \
    --technical_file "data_processor/outputs/mean_weighted.xlsx" \
    --sentiment_file "data_processor/outputs/sentiment_signals.csv" \
    --weight_step 0.1
```

### 步骤 3: 使用最优权重

根据 `fuse_signals.py` 的输出，更新 `portfolio_manager.py` 中的权重。

---

## 📈 预期收益

通过优化融合策略，您可以：

1. **提高收益率**: 通过最优权重组合
2. **降低风险**: 通过自适应权重调整
3. **提高稳定性**: 通过多信号融合

**建议**: 先运行小规模测试（1个月，5只股票），验证流程后再运行完整数据。

---

## ✅ 总结

您的思路是**完全正确**的：

1. ✅ **分阶段实现** - 更清晰、更易调试
2. ✅ **先生成情感信号** - 合理的工作流程
3. ✅ **后续优化融合策略** - 可以基于实际数据优化
4. ✅ **利用已有技术信号** - 避免重复计算

**下一步**: 运行 `generate_sentiment_signals.py` 开始生成情感信号！


