#!/usr/bin/env python3
"""
Save results to Google Drive
Helper script to save generated files to Google Drive in Colab
"""

import os
import shutil
from datetime import datetime

def save_to_drive(file_path, drive_base='/content/drive/MyDrive/Colab_Results', subfolder=None):
    """
    Save file to Google Drive
    
    Args:
        file_path: Path to file to save
        drive_base: Base directory in Drive (default: /content/drive/MyDrive/Colab_Results)
        subfolder: Optional subfolder name (default: timestamp-based)
    
    Returns:
        str: Path where file was saved in Drive
    """
    try:
        from google.colab import drive
    except ImportError:
        print("⚠️  Not in Colab environment. Cannot save to Google Drive.")
        return None
    
    # Mount Drive
    try:
        drive.mount('/content/drive', force_remount=False)
    except Exception as e:
        print(f"⚠️  Warning: Could not mount Drive: {e}")
        return None
    
    # Create directory
    if subfolder is None:
        timestamp = datetime.now().strftime('%Y%m%d_%H%M%S')
        subfolder = f'results_{timestamp}'
    
    drive_dir = os.path.join(drive_base, subfolder)
    os.makedirs(drive_dir, exist_ok=True)
    
    # Copy file
    if not os.path.exists(file_path):
        print(f"✗ File not found: {file_path}")
        return None
    
    filename = os.path.basename(file_path)
    drive_path = os.path.join(drive_dir, filename)
    shutil.copy(file_path, drive_path)
    
    print(f"✓ Saved to Google Drive: {drive_path}")
    return drive_path


def save_multiple_to_drive(file_paths, drive_base='/content/drive/MyDrive/Colab_Results', subfolder=None):
    """
    Save multiple files to Google Drive
    
    Args:
        file_paths: List of file paths to save
        drive_base: Base directory in Drive
        subfolder: Optional subfolder name
    
    Returns:
        dict: Mapping of original paths to Drive paths
    """
    try:
        from google.colab import drive
    except ImportError:
        print("⚠️  Not in Colab environment. Cannot save to Google Drive.")
        return {}
    
    # Mount Drive
    try:
        drive.mount('/content/drive', force_remount=False)
    except Exception as e:
        print(f"⚠️  Warning: Could not mount Drive: {e}")
        return {}
    
    # Create directory
    if subfolder is None:
        timestamp = datetime.now().strftime('%Y%m%d_%H%M%S')
        subfolder = f'results_{timestamp}'
    
    drive_dir = os.path.join(drive_base, subfolder)
    os.makedirs(drive_dir, exist_ok=True)
    print(f"Drive directory: {drive_dir}")
    
    # Copy files
    saved_files = {}
    for file_path in file_paths:
        if os.path.exists(file_path):
            filename = os.path.basename(file_path)
            drive_path = os.path.join(drive_dir, filename)
            shutil.copy(file_path, drive_path)
            saved_files[file_path] = drive_path
            print(f"✓ Saved: {filename}")
        else:
            print(f"✗ File not found: {file_path}")
    
    print(f"\n✓ Saved {len(saved_files)} files to Google Drive")
    print(f"Path: {drive_dir}")
    return saved_files


if __name__ == "__main__":
    import sys
    
    if len(sys.argv) < 2:
        print("Usage: python save_to_drive.py <file1> [file2] ...")
        print("Example: python save_to_drive.py data_processor/outputs/sentiment_signals.csv")
        sys.exit(1)
    
    files_to_save = sys.argv[1:]
    
    if len(files_to_save) == 1:
        save_to_drive(files_to_save[0])
    else:
        save_multiple_to_drive(files_to_save)

