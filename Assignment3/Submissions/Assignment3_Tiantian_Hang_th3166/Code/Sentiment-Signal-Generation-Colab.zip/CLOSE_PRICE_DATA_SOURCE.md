# Close 价格数据来源说明

## 📊 核心答案

**Close 价格不是从 `sp500_tickers_daily_price.csv` 文件中抓取的！**

Close 价格是通过 **`yfinance` API 实时从网络获取**的。

---

## 🔍 详细说明

### 1. Close 价格的获取方式

**位置**: `news_fetcher/data_fetcher.py` → `get_stock_data()` 函数

**代码**:
```python
def get_stock_data(self, stock_symbol, steps):
    """
    Get stock price data for given dates
    """
    # 使用 yfinance 从网络实时下载股票数据
    stock_data = yf.download(stock_symbol, steps[0], steps[-1], progress=False)
    
    # 从下载的数据中提取 Close 价格
    # ...
```

**数据源**: 
- ✅ **yfinance API** (Yahoo Finance)
- ❌ **不是** `sp500_tickers_daily_price.csv` 文件

---

### 2. `sp500_tickers_daily_price.csv` 文件的真实用途

**位置**: `news_fetcher/data_fetcher.py` → `build_gvkey_to_ticker_map()` 函数

**代码**:
```python
def build_gvkey_to_ticker_map(self, price_data_path=None, price_data=None):
    """
    Build mapping from gvkey to ticker symbol
    """
    # 只读取 gvkey 和 tic 列，用于构建映射
    price_data = pd.read_csv(
        price_data_path, 
        usecols=['gvkey', 'tic'],  # 只读取这两列！
        dtype={'gvkey': 'Int64', 'tic': 'str'}
    )
    
    # 创建 gvkey → ticker 的映射字典
    mapping = price_data.groupby('gvkey')['tic'].last().to_dict()
    
    return mapping
```

**用途**:
- ✅ **构建 gvkey → ticker 映射关系**
- ✅ 将数据库中的 `gvkey` (如 1078) 转换为股票代码 `ticker` (如 "AAPL")
- ❌ **不用于获取 Close 价格**

---

## 🔄 完整数据流程

```
1. 加载 stock_selected.csv
   └── 包含: gvkey, trade_date, predicted_return
   
2. 使用 sp500_tickers_daily_price.csv 构建映射
   └── 读取: gvkey, tic (ticker)
   └── 输出: {gvkey: ticker} 字典
   └── 例如: {1078: "AAPL", 1161: "MSFT", ...}
   
3. 对每个 (gvkey, trade_date) 组合:
   ├── 通过映射获取 ticker (如 "AAPL")
   ├── 调用 yfinance API 获取 Close 价格 ← 这里！
   │   └── yf.download("AAPL", start_date, end_date)
   │   └── 从网络实时下载，不读取本地文件
   └── 使用 Close 价格构建 prompt
```

---

## 📋 为什么需要 `sp500_tickers_daily_price.csv`？

### 问题
- `stock_selected.csv` 使用 `gvkey` (数据库标识符，如 1078)
- `yfinance` API 需要 `ticker` (股票代码，如 "AAPL")
- 需要建立两者之间的对应关系

### 解决方案
使用 `sp500_tickers_daily_price.csv` 文件中的 `gvkey` 和 `tic` 列来构建映射：

```python
# 从文件中读取映射关系
gvkey_to_ticker = {
    1078: "AAPL",   # Apple
    1161: "MSFT",   # Microsoft
    2991: "CVX",    # Chevron
    ...
}

# 然后使用 ticker 调用 yfinance
ticker = gvkey_to_ticker[1078]  # "AAPL"
stock_data = yf.download(ticker, ...)  # 从网络获取价格
```

---

## 🎯 总结

| 数据项 | 数据源 | 用途 |
|--------|--------|------|
| **Close 价格** | `yfinance` API (网络) | 构建历史价格-新闻对应关系，用于 LLM prompt |
| **gvkey → ticker 映射** | `sp500_tickers_daily_price.csv` | 将 gvkey 转换为 ticker，以便调用 yfinance |

---

## 💡 关键理解

1. **`sp500_tickers_daily_price.csv` 不包含 Close 价格数据用于 sentiment 分析**
   - 它只用于构建 `gvkey → ticker` 映射

2. **Close 价格是实时从网络获取的**
   - 每次运行 `generate_sentiment_signals.py` 时，都会通过 `yfinance` 从 Yahoo Finance 下载最新的价格数据

3. **为什么不在本地文件读取 Close 价格？**
   - 灵活性：可以获取任意日期范围的价格
   - 实时性：总是获取最新的价格数据
   - 简化：不需要维护本地价格数据库

---

## 🔧 如果 yfinance 获取失败怎么办？

如果 `yfinance` API 调用失败（网络问题、股票代码无效等），会抛出错误：

```python
if len(stock_data) == 0:
    raise ValueError(f"Failed to download stock price data for symbol {stock_symbol}")
```

这就是为什么之前会出现 `No 'Close' column found` 错误的原因：
- `yfinance` 可能返回了空数据或格式异常的数据
- 代码已经修复，现在会更好地处理这种情况

