"""
Google Colab Setup Script for Dual-Insight Trader
Run this first in Google Colab to set up the environment
"""

import os
import subprocess
import sys

def install_requirements():
    """Install required packages"""
    print("Installing requirements...")
    subprocess.check_call([
        sys.executable, "-m", "pip", "install", 
        "-r", "requirements.txt", "--quiet"
    ])
    print("✓ Requirements installed")

def setup_environment():
    """Set up environment variables"""
    print("\nSetting up environment...")
    
    # Check for API keys
    finnhub_key = os.environ.get('FINNHUB_API_KEY') or os.environ.get('FINNHUB_KEY')
    hf_token = os.environ.get('HF_TOKEN')
    
    if not finnhub_key:
        print("⚠️  Warning: FINNHUB_API_KEY not found in environment")
        print("   Please set it using: os.environ['FINNHUB_API_KEY'] = 'your_key'")
    
    if not hf_token:
        print("⚠️  Warning: HF_TOKEN not found in environment")
        print("   Please set it using: os.environ['HF_TOKEN'] = 'your_token'")
    
    if finnhub_key and hf_token:
        print("✓ API keys found in environment")
    
    print("\n✓ Environment setup complete")

def check_gpu():
    """Check GPU availability"""
    print("\nChecking GPU...")
    try:
        import torch
        if torch.cuda.is_available():
            print(f"✓ GPU available: {torch.cuda.get_device_name(0)}")
            print(f"  CUDA Version: {torch.version.cuda}")
            print(f"  GPU Memory: {torch.cuda.get_device_properties(0).total_memory / 1e9:.2f} GB")
        else:
            print("⚠️  No GPU detected. Model loading will be slow.")
    except ImportError:
        print("⚠️  PyTorch not installed yet")

if __name__ == "__main__":
    print("=" * 80)
    print("Dual-Insight Trader - Google Colab Setup")
    print("=" * 80)
    
    install_requirements()
    setup_environment()
    check_gpu()
    
    print("\n" + "=" * 80)
    print("Setup Complete!")
    print("=" * 80)
    print("\nNext steps:")
    print("1. Set your API keys:")
    print("   os.environ['FINNHUB_API_KEY'] = 'your_key'")
    print("   os.environ['HF_TOKEN'] = 'your_token'")
    print("\n2. Run the test:")
    print("   !python run_test.py")
    print("\n3. Or run full backtest:")
    print("   !python main.py --start_date '2024-12-01' --end_date '2025-11-30' \\")
    print("                  --data_dir 'data_processor/outputs' \\")
    print("                  --price_file '../dec data/sp500_tickers_daily_price.csv'")


