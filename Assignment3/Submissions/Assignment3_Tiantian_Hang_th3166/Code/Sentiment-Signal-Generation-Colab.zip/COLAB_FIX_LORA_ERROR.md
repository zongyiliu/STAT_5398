# Colab LoRA 加载错误修复指南

## 问题描述

运行 `test_sentiment_colab.py` 时遇到错误：

```
KeyError: 'base_model.model.model.lm_head'
```

这个错误发生在加载 LoRA adapter 时，通常是由于：
1. PEFT 库版本不兼容
2. 模型结构不匹配
3. `device_map="auto"` 导致的设备分配问题

---

## 解决方案

### 方案 1: 使用修复后的代码（推荐）✅

我已经修复了 `sentiment_agent.py`，添加了错误处理和回退机制。如果 LoRA 加载失败，会自动使用 Base Model。

**修复内容**:
- 添加了 try-except 错误处理
- 如果 LoRA 加载失败，自动回退到 Base Model
- 显示清晰的警告信息

### 方案 2: 更新 PEFT 库版本

在 Colab 中运行：

```python
!pip install --upgrade peft transformers
```

### 方案 3: 使用 Llama 3.1 版本（无需 LoRA）

使用新的 Llama 3.1 版本，不需要 LoRA adapter：

```python
# 使用新的测试脚本
!python test_sentiment_colab_llama31.py
```

---

## 快速修复步骤

### 在 Colab 中修复

#### 方法 1: 直接修改文件

在 Colab 中运行：

```python
# 修改 sentiment_agent.py
import os

# 读取文件
with open('/content/signal_generator/sentiment_agent.py', 'r') as f:
    content = f.read()

# 替换代码
old_code = '''        print(f"Loading LoRA adapter: {lora_model_path}")
        self.model = PeftModel.from_pretrained(
            self.base_model,
            lora_model_path,
        )
        self.model = self.model.eval()'''

new_code = '''        # Try to load LoRA adapter, fallback to base model if it fails
        print(f"Loading LoRA adapter: {lora_model_path}")
        try:
            self.model = PeftModel.from_pretrained(
                self.base_model,
                lora_model_path,
            )
            print("✓ LoRA adapter loaded successfully")
        except Exception as e:
            print(f"⚠️  Failed to load LoRA adapter: {e}")
            print("   Using base model without LoRA (this may affect performance)")
            self.model = self.base_model
        
        self.model = self.model.eval()'''

content = content.replace(old_code, new_code)

# 保存文件
with open('/content/signal_generator/sentiment_agent.py', 'w') as f:
    f.write(content)

print("✓ File updated successfully")
```

#### 方法 2: 重新上传修复后的 ZIP

1. 下载修复后的 `Sentiment-Signal-Generation-Colab.zip`
2. 在 Colab 中重新上传并解压

---

## 验证修复

运行测试脚本：

```python
!python test_sentiment_colab.py
```

**预期输出**:
- 如果 LoRA 加载成功：`✓ LoRA adapter loaded successfully`
- 如果 LoRA 加载失败：`⚠️  Failed to load LoRA adapter: ...` 然后继续使用 Base Model

---

## 为什么会出现这个错误？

### 原因分析

1. **PEFT 版本问题**: 不同版本的 PEFT 库对模型结构的处理方式不同
2. **设备分配**: `device_map="auto"` 可能将模型分片到不同设备，导致 LoRA 加载时找不到某些层
3. **模型结构变化**: HuggingFace 的模型结构可能有细微变化

### 技术细节

错误发生在 `peft/peft_model.py` 的 `_update_offload` 方法中，尝试访问 `base_model.model.model.lm_head` 时失败。

---

## 替代方案

### 选项 1: 不使用 device_map

修改模型加载方式（可能占用更多显存）：

```python
self.base_model = AutoModelForCausalLM.from_pretrained(
    base_model_path,
    token=self.hf_token,
    trust_remote_code=True,
    # device_map="auto",  # 注释掉这行
    torch_dtype=torch.float16,
)
self.base_model = self.base_model.to("cuda")  # 手动移动到 GPU
```

### 选项 2: 使用 offload_folder

参考 FinGPT_Forecaster 的方式：

```python
self.base_model = AutoModelForCausalLM.from_pretrained(
    base_model_path,
    token=self.hf_token,
    trust_remote_code=True,
    device_map="auto",
    torch_dtype=torch.float16,
    offload_folder="offload/"  # 添加这行
)

self.model = PeftModel.from_pretrained(
    self.base_model,
    lora_model_path,
    offload_folder="offload/"  # 添加这行
)
```

### 选项 3: 使用 Llama 3.1（推荐）

使用新的 Llama 3.1 版本，不需要 LoRA：

```python
# 使用新的脚本
!python generate_sentiment_signals_llama31.py \
    --stock_selected_file "/content/stock_selected.csv" \
    --price_file "/content/sp500_tickers_daily_price.csv" \
    --max_stocks 5 \
    --start_date "2024-12-01" \
    --end_date "2024-12-31"
```

---

## 完整修复代码

在 Colab 中运行以下代码来修复：

```python
# 修复 sentiment_agent.py
import re

# 读取文件
with open('/content/signal_generator/sentiment_agent.py', 'r') as f:
    content = f.read()

# 查找并替换
pattern = r'(print\(f"Loading LoRA adapter: \{lora_model_path\}"\)\s+self\.model = PeftModel\.from_pretrained\(\s+self\.base_model,\s+lora_model_path,\s+\)\s+self\.model = self\.model\.eval\(\))'

replacement = '''print(f"Loading LoRA adapter: {lora_model_path}")
        try:
            self.model = PeftModel.from_pretrained(
                self.base_model,
                lora_model_path,
            )
            print("✓ LoRA adapter loaded successfully")
        except Exception as e:
            print(f"⚠️  Failed to load LoRA adapter: {e}")
            print("   Using base model without LoRA (this may affect performance)")
            self.model = self.base_model
        
        self.model = self.model.eval()'''

content = re.sub(pattern, replacement, content)

# 保存文件
with open('/content/signal_generator/sentiment_agent.py', 'w') as f:
    f.write(content)

print("✓ File fixed! Now try running the test again.")
```

---

## 测试修复

修复后，运行测试：

```python
!python test_sentiment_colab.py
```

**成功标志**:
- 不再出现 `KeyError`
- 看到 `✓ LoRA adapter loaded successfully` 或 `⚠️  Failed to load LoRA adapter`（但继续运行）
- 测试完成并生成输出文件

---

## 如果仍然失败

### 选项 1: 完全禁用 LoRA

修改 `sentiment_agent.py`，直接使用 Base Model：

```python
# 注释掉 LoRA 加载部分
# self.model = PeftModel.from_pretrained(...)
self.model = self.base_model
```

### 选项 2: 使用 Llama 3.1 版本

切换到新的 Llama 3.1 版本（不需要 LoRA）：

```python
# 上传新的 ZIP: Sentiment-Signal-Generation-Llama31-Colab.zip
# 然后运行
!python test_sentiment_colab_llama31.py
```

---

## 总结

**推荐解决方案**:
1. ✅ 使用修复后的代码（添加了错误处理）
2. ✅ 如果 LoRA 加载失败，自动使用 Base Model
3. ✅ 或者切换到 Llama 3.1 版本（不需要 LoRA）

**修复后的行为**:
- 尝试加载 LoRA adapter
- 如果失败，自动回退到 Base Model
- 继续运行，不会中断

这样即使 LoRA 加载失败，代码也能继续运行，只是性能可能略低。

