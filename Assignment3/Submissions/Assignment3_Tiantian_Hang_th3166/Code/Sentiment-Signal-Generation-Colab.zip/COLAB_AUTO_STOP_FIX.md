# 修复 Colab 自动停止问题

## 🔍 问题诊断

如果代码在模型加载时自动停止（没有手动中断），可能的原因：

### 1. **Colab 运行时超时**
- **免费版 Colab**：如果长时间无输出，会自动断开连接
- **解决方案**：保持浏览器标签页打开，定期有输出

### 2. **模型下载超时**
- HuggingFace 模型下载可能因为网络问题中断
- **解决方案**：已添加自动重试机制

### 3. **内存不足**
- 模型下载和加载需要大量内存
- **解决方案**：使用 GPU，释放其他内存

### 4. **网络连接问题**
- 下载大文件（~13GB）时网络不稳定
- **解决方案**：使用 `resume_download=True` 支持断点续传

---

## ✅ 已实施的修复

### 1. 自动重试机制

代码现在会自动重试失败的模型加载：

```python
# 最多重试 3 次，每次间隔 60 秒
for attempt in range(max_retries):
    try:
        self.base_model = AutoModelForCausalLM.from_pretrained(
            ...,
            resume_download=True,  # 支持断点续传
        )
        break
    except Exception as e:
        if attempt < max_retries - 1:
            time.sleep(60)  # 等待 60 秒后重试
        else:
            raise
```

### 2. 进度提示

添加了更详细的进度提示：

```
Loading base model: meta-llama/Llama-2-7b-chat-hf
   This may take several minutes, especially on CPU...
   Model size: ~13GB, download may take 10-20 minutes
   Please be patient and do not close the browser tab...
   Attempt 1/3...
```

### 3. 断点续传

使用 `resume_download=True` 支持断点续传：
- 如果下载中断，下次会自动从断点继续
- 不需要重新下载整个模型

---

## 🛠️ 解决方案

### 方案 1: 保持浏览器标签页打开（最重要）

**关键**：在模型下载期间：
- ✅ **保持浏览器标签页打开**
- ✅ **不要切换到其他标签页**
- ✅ **不要关闭浏览器**
- ✅ **定期检查输出**（每 5-10 分钟）

**原因**：Colab 会检测标签页是否活跃，如果长时间无活动可能断开连接。

### 方案 2: 使用 GPU（强烈推荐）

**为什么 GPU 重要**：
- GPU 下载和加载更快（5-10 分钟 vs 20-30 分钟）
- 减少超时风险
- 更稳定的连接

**步骤**：
1. `Runtime → Change runtime type → GPU`
2. 选择 `T4`（免费）或 `A100`（付费）
3. 保存并重启运行时

### 方案 3: 分批下载模型

如果网络不稳定，可以手动下载模型：

```python
# 在单独的单元格中运行
from huggingface_hub import snapshot_download
import os

os.environ['HF_TOKEN'] = 'your_token_here'

# 下载模型到本地缓存
snapshot_download(
    "meta-llama/Llama-2-7b-chat-hf",
    token=os.environ['HF_TOKEN'],
    resume_download=True,
    local_dir="/content/models/llama-2-7b-chat-hf"
)

print("✓ Model downloaded successfully")
```

然后修改代码使用本地路径：

```python
# 修改 sentiment_agent.py 中的 base_model_path
base_model_path = "/content/models/llama-2-7b-chat-hf"
```

### 方案 4: 增加 Colab 会话时间

**免费版限制**：
- 每次会话最多 12 小时
- 如果无活动可能提前断开

**建议**：
- 使用 `--resume` 选项支持断点续传
- 分批处理数据
- 定期保存中间结果

---

## 🔧 故障排除步骤

### 步骤 1: 检查连接状态

```python
# 检查是否还在连接
import time
for i in range(10):
    print(f"Still connected... {i+1}/10")
    time.sleep(1)
```

### 步骤 2: 检查模型下载进度

```python
# 检查 HuggingFace 缓存
from huggingface_hub import scan_cache_dir

cache_info = scan_cache_dir()
print(f"Cache size: {cache_info.size_on_disk_str}")
print(f"Cached repos: {len(cache_info.repos)}")

# 检查是否有部分下载的模型
for repo in cache_info.repos:
    if 'llama' in repo.repo_id.lower():
        print(f"Found: {repo.repo_id}")
```

### 步骤 3: 手动清理并重试

如果下载卡住，可以清理缓存后重试：

```python
# 清理 HuggingFace 缓存（可选）
from huggingface_hub import scan_cache_dir, delete_revisions

cache_info = scan_cache_dir()
# 只删除特定模型的缓存
for repo in cache_info.repos:
    if 'llama-2-7b-chat-hf' in repo.repo_id:
        print(f"Deleting cache for {repo.repo_id}...")
        delete_revisions(repo.repo_id)
```

### 步骤 4: 使用更稳定的网络

如果网络不稳定：
- 尝试使用 VPN
- 或者使用其他网络环境
- 考虑使用 Google Colab Pro（更稳定的连接）

---

## 📋 最佳实践

### 1. 首次运行

```python
# 步骤 1: 先单独下载模型（在单独的单元格）
from transformers import AutoModelForCausalLM
import os

os.environ['HF_TOKEN'] = 'your_token'

print("Downloading model (this may take 10-20 minutes)...")
model = AutoModelForCausalLM.from_pretrained(
    'meta-llama/Llama-2-7b-chat-hf',
    token=os.environ['HF_TOKEN'],
    resume_download=True,
    device_map='auto',
    torch_dtype=torch.float16,
)
print("✓ Model downloaded and cached")

# 步骤 2: 然后运行主脚本
# 模型已经在缓存中，加载会很快
```

### 2. 监控进度

```python
# 在另一个单元格中运行，监控进度
import time
import os

while True:
    # 检查是否有新的输出文件
    if os.path.exists('sentiment_signals.csv'):
        print(f"✓ Output file exists: {os.path.getsize('sentiment_signals.csv')} bytes")
    
    # 检查 GPU 使用情况
    import torch
    if torch.cuda.is_available():
        print(f"GPU Memory: {torch.cuda.memory_allocated(0) / 1e9:.2f} GB")
    
    time.sleep(60)  # 每分钟检查一次
```

### 3. 使用断点续传

```python
# 使用 --resume 选项（默认启用）
!python generate_sentiment_signals.py \
    --stock_selected_file /content/stock_selected.csv \
    --price_file /content/sp500_tickers_daily_price.csv \
    --output_file sentiment_signals.csv \
    --start_date 2024-12-01 \
    --end_date 2024-12-31
    # --resume 是默认的，会自动跳过已处理的记录
```

---

## ⚠️ 常见问题

### Q1: 为什么模型下载这么慢？

**A**: 
- 模型文件很大（~13GB）
- 需要从 HuggingFace 下载
- 网络速度限制

**解决方案**：
- 使用 GPU（下载更快）
- 保持网络稳定
- 使用 `resume_download=True` 支持断点续传

### Q2: 下载到一半就停止了？

**A**: 
- 可能是网络中断
- 或者 Colab 连接断开

**解决方案**：
- 代码已添加自动重试机制
- 使用 `resume_download=True` 会自动从断点继续
- 重新运行代码，不会重新下载已下载的部分

### Q3: 如何知道下载进度？

**A**: 
- HuggingFace 会自动显示下载进度条
- 如果卡住，可能是网络问题，等待自动重试

### Q4: 可以离线使用已下载的模型吗？

**A**: 
- 可以！模型会缓存在 Colab 环境中
- 下次运行时，如果模型已缓存，会直接加载（很快）
- 缓存位置：`~/.cache/huggingface/`

---

## 🎯 推荐工作流程

### 第一次运行（下载模型）

1. **启用 GPU**：`Runtime → Change runtime type → GPU`
2. **保持标签页打开**：不要关闭浏览器
3. **运行代码**：让模型下载完成（10-20 分钟）
4. **监控输出**：定期检查是否有错误

### 后续运行（模型已缓存）

1. **直接运行**：模型已在缓存中，加载很快（2-5 分钟）
2. **使用断点续传**：如果中断，重新运行会自动继续

---

## 📝 相关文件

- `signal_generator/sentiment_agent.py` - 已添加重试机制
- `COLAB_ENABLE_GPU_GUIDE.md` - GPU 启用指南
- `COLAB_FIX_DEVICE_META_ERROR.md` - 设备错误修复

---

## 🎯 总结

**主要修复**：
- ✅ 添加自动重试机制（最多 3 次）
- ✅ 支持断点续传（`resume_download=True`）
- ✅ 更详细的进度提示
- ✅ 更好的错误处理

**用户操作**：
- ✅ **保持浏览器标签页打开**
- ✅ **启用 GPU**（强烈推荐）
- ✅ **耐心等待**（首次下载需要 10-20 分钟）

**如果仍然停止**：
- 检查网络连接
- 重新运行代码（会自动从断点继续）
- 考虑使用 Colab Pro（更稳定的连接）

