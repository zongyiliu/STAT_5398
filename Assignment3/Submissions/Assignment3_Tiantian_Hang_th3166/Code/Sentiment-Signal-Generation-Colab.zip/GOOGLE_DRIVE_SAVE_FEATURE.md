# Google Drive 自动保存功能说明

## ✅ 功能状态

**已添加**: 代码中现在包含了保存到 Google Drive 的功能！

---

## 📋 功能说明

### 1. 自动保存功能（已集成）

`generate_sentiment_signals.py` 现在支持自动保存到 Google Drive：

- ✅ **自动检测**: 如果在 Colab 环境中运行，会自动检测
- ✅ **可选启用**: 通过参数或环境变量控制
- ✅ **自动挂载**: 自动挂载 Google Drive
- ✅ **带时间戳**: 自动创建带时间戳的文件夹

### 2. 辅助脚本

`save_to_drive.py` - 独立的保存脚本，可以单独使用

---

## 🚀 使用方法

### 方法 1: 使用命令行参数（推荐）

```python
# 在 Colab 中运行
!python generate_sentiment_signals.py \
    --data_dir "data_processor/outputs" \
    --price_file "dec data/sp500_tickers_daily_price.csv" \
    --save_to_drive  # 添加这个参数
```

### 方法 2: 使用环境变量

```python
import os

# 设置环境变量
os.environ['SAVE_TO_DRIVE'] = 'true'

# 运行脚本
!python generate_sentiment_signals.py \
    --data_dir "data_processor/outputs" \
    --price_file "dec data/sp500_tickers_daily_price.csv"
```

### 方法 3: 使用辅助脚本（生成后保存）

```python
# 先生成文件
!python generate_sentiment_signals.py

# 然后保存到 Drive
!python save_to_drive.py data_processor/outputs/sentiment_signals.csv
```

### 方法 4: 保存多个文件

```python
!python save_to_drive.py \
    data_processor/outputs/sentiment_signals.csv \
    data_processor/outputs/fusion_results.csv
```

---

## 📁 保存位置

文件会保存到：
```
/content/drive/MyDrive/Colab_Results/sentiment_signals_YYYYMMDD_HHMMSS/
```

例如：
```
/content/drive/MyDrive/Colab_Results/sentiment_signals_20241207_143022/sentiment_signals.csv
```

---

## 💡 完整示例

### 在 Colab Notebook 中

```python
# 1. 设置 API Keys
import os
os.environ['FINNHUB_API_KEY'] = 'your_key'
os.environ['HF_TOKEN'] = 'your_token'

# 2. 运行生成（自动保存到 Drive）
!python generate_sentiment_signals.py \
    --data_dir "data_processor/outputs" \
    --price_file "dec data/sp500_tickers_daily_price.csv" \
    --save_to_drive

# 3. 从 Drive 下载（可选）
# 访问 https://drive.google.com
# 进入 Colab_Results 文件夹
# 找到对应的文件夹并下载
```

---

## 🔧 代码实现细节

### 在 `generate_sentiment_signals.py` 中

保存逻辑在 `generate_sentiment_signals()` 函数的最后：

```python
# Save final results
if results:
    df_results = pd.DataFrame(results)
    df_results.to_csv(output_file, index=False)
    print(f"\n✓ Saved {len(results)} sentiment signals to {output_file}")
    
    # Optionally save to Google Drive if in Colab environment
    if save_to_drive:
        try:
            from google.colab import drive
            import shutil
            from datetime import datetime
            
            # Mount Drive
            drive.mount('/content/drive', force_remount=False)
            
            # Create Drive directory
            drive_base = '/content/drive/MyDrive/Colab_Results'
            timestamp = datetime.now().strftime('%Y%m%d_%H%M%S')
            drive_dir = os.path.join(drive_base, f'sentiment_signals_{timestamp}')
            os.makedirs(drive_dir, exist_ok=True)
            
            # Copy file to Drive
            filename = os.path.basename(output_file)
            drive_path = os.path.join(drive_dir, filename)
            shutil.copy(output_file, drive_path)
            
            print(f"✓ Also saved to Google Drive: {drive_path}")
        except Exception as e:
            print(f"⚠️  Warning: Could not save to Google Drive: {e}")
```

---

## ⚙️ 参数说明

### `--save_to_drive`
- **类型**: 标志（flag）
- **说明**: 启用自动保存到 Google Drive
- **默认**: False（不保存）
- **要求**: 必须在 Colab 环境中运行

---

## ⚠️ 注意事项

### 1. Colab 环境要求
- 必须在 Google Colab 中运行
- 会自动检测 Colab 环境
- 非 Colab 环境会跳过保存（不会报错）

### 2. Drive 挂载
- 首次挂载需要授权
- 会弹出授权窗口
- 授权后会自动完成保存

### 3. 文件大小
- 无大小限制
- 适合保存大文件
- 比直接下载更稳定

### 4. 存储空间
- 使用您的 Google Drive 存储空间
- 免费版: 15GB
- 建议定期清理旧文件

---

## 🔄 工作流程

```
运行 generate_sentiment_signals.py
    ↓
生成 sentiment_signals.csv（本地）
    ↓
如果 --save_to_drive 或 SAVE_TO_DRIVE=true
    ↓
检测 Colab 环境
    ↓
挂载 Google Drive
    ↓
创建带时间戳的文件夹
    ↓
复制文件到 Drive
    ↓
完成！
```

---

## 📊 对比

| 方法 | 优点 | 缺点 | 适用场景 |
|------|------|------|---------|
| **自动保存（--save_to_drive）** | 一键完成，无需额外步骤 | 需要 Colab 环境 | 推荐 ✅ |
| **辅助脚本（save_to_drive.py）** | 灵活，可保存任意文件 | 需要额外运行 | 保存多个文件 |
| **手动代码** | 完全控制 | 需要编写代码 | 自定义需求 |

---

## 🎯 推荐使用方式

### 在 Colab 中运行完整流程

```python
# 完整流程：生成 + 自动保存到 Drive
!python generate_sentiment_signals.py \
    --data_dir "data_processor/outputs" \
    --price_file "dec data/sp500_tickers_daily_price.csv" \
    --save_to_drive
```

**优势**:
- ✅ 一键完成
- ✅ 自动保存
- ✅ 无需额外步骤
- ✅ 带时间戳，便于管理

---

## 📝 总结

**回答您的问题**: 

**之前**: 代码中**没有**包含保存到 Google Drive 的功能，只有文档中有示例代码。

**现在**: 代码中**已经添加**了保存到 Google Drive 的功能！

- ✅ `generate_sentiment_signals.py` 支持 `--save_to_drive` 参数
- ✅ 自动检测 Colab 环境
- ✅ 自动挂载和保存
- ✅ 创建了 `save_to_drive.py` 辅助脚本

**使用**: 只需添加 `--save_to_drive` 参数即可！

