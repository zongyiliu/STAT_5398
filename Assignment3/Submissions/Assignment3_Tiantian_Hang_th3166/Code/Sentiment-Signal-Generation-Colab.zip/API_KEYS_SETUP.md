# API Keys 设置指南

## 概述

本项目需要以下 API Keys 才能正常运行。请按照本指南设置。

## 设置方法

### 方法 1: 使用 .env 文件（推荐）

1. **复制模板文件**：
   ```bash
   cd "Dual-Insight Trader"
   cp .env.example .env
   ```

2. **编辑 .env 文件**：
   使用文本编辑器打开 `.env` 文件，填入你的 API keys：
   ```bash
   # 使用任何文本编辑器
   nano .env
   # 或
   vim .env
   # 或
   open -e .env  # macOS
   ```

3. **填入 API Keys**：
   ```env
   FINNHUB_KEY=你的finnhub_api_key
   FINNHUB_API_KEY=你的finnhub_api_key
   HF_TOKEN=你的huggingface_token
   ```

4. **安装 python-dotenv**（如果代码需要）：
   ```bash
   pip install python-dotenv
   ```

### 方法 2: 使用环境变量（临时）

在终端中直接设置（每次新开终端需要重新设置）：

```bash
# macOS/Linux
export FINNHUB_KEY='your_finnhub_api_key'
export FINNHUB_API_KEY='your_finnhub_api_key'
export HF_TOKEN='your_huggingface_token'

# Windows (PowerShell)
$env:FINNHUB_KEY='your_finnhub_api_key'
$env:FINNHUB_API_KEY='your_finnhub_api_key'
$env:HF_TOKEN='your_huggingface_token'
```

### 方法 3: 在 shell 配置文件中设置（永久）

将环境变量添加到你的 shell 配置文件中：

**macOS/Linux (bash/zsh)**:
```bash
# 编辑 ~/.zshrc 或 ~/.bashrc
nano ~/.zshrc

# 添加以下行
export FINNHUB_KEY='your_finnhub_api_key'
export FINNHUB_API_KEY='your_finnhub_api_key'
export HF_TOKEN='your_huggingface_token'

# 重新加载配置
source ~/.zshrc
```

## 必需的 API Keys

### 1. Finnhub API Key ⭐ **必需**

**用途**: 获取股票新闻数据

**获取步骤**:
1. 访问 https://finnhub.io/
2. 注册账号（免费）
3. 登录后，在 Dashboard 中找到 API Key
4. 复制 API Key

**设置**:
```env
FINNHUB_KEY=你的finnhub_api_key
# 或
FINNHUB_API_KEY=你的finnhub_api_key
```

**限制**: 免费版 60 次调用/分钟

---

### 2. HuggingFace Token ⭐ **必需**（如果要使用 Sentiment Agent）

**用途**: 下载 FinGPT 模型

**获取步骤**:
1. 访问 https://huggingface.co/
2. 注册账号（免费）
3. 在 Settings → Access Tokens 中创建 token
4. 选择 "Read" 权限
5. **重要**: 需要申请访问 `meta-llama/Llama-2-7b-chat-hf` 的权限
   - 访问 https://huggingface.co/meta-llama/Llama-2-7b-chat-hf
   - 点击 "Request access"
   - 等待批准（通常很快）

**设置**:
```env
HF_TOKEN=你的huggingface_token
```

---

## 可选 API Keys

### 3. OpenAI API Key（可选）

**用途**: 生成训练数据（仅在生成新数据集时需要）

**获取步骤**:
1. 访问 https://platform.openai.com/
2. 注册账号并充值
3. 在 API Keys 页面创建新 key

**设置**:
```env
OPENAI_KEY=你的openai_api_key
```

---

## 验证设置

运行以下命令验证 API keys 是否设置正确：

```bash
cd "Dual-Insight Trader"

# 检查环境变量
echo "FINNHUB_KEY: ${FINNHUB_KEY:0:10}..."  # 只显示前10个字符
echo "HF_TOKEN: ${HF_TOKEN:0:10}..."

# 或使用 Python 检查
python3 -c "
import os
from dotenv import load_dotenv
load_dotenv()

finnhub = os.getenv('FINNHUB_KEY') or os.getenv('FINNHUB_API_KEY')
hf = os.getenv('HF_TOKEN')

print(f'FINNHUB_KEY: {\"✓ 已设置\" if finnhub else \"✗ 未设置\"}')
print(f'HF_TOKEN: {\"✓ 已设置\" if hf else \"✗ 未设置\"}')
"
```

## 文件位置

- **模板文件**: `.env.example` - 包含所有需要的环境变量模板
- **实际配置**: `.env` - 你的实际 API keys（**不要提交到 Git！**）
- **Git 忽略**: `.gitignore` 已包含 `.env`，确保不会被提交

## 安全提示

⚠️ **重要安全提示**:

1. **永远不要**将 `.env` 文件提交到 Git
2. **永远不要**在代码中硬编码 API keys
3. **永远不要**在公开场合分享你的 API keys
4. `.gitignore` 已配置忽略 `.env` 文件
5. 如果 API key 泄露，立即在对应平台重新生成

## 代码中的使用

代码会自动从环境变量读取：

```python
# news_fetcher/data_fetcher.py
api_key = finnhub_key or os.environ.get("FINNHUB_KEY") or os.environ.get("FINNHUB_API_KEY")

# signal_generator/sentiment_agent.py
self.hf_token = hf_token or os.environ.get("HF_TOKEN")
```

如果使用 `.env` 文件，需要在代码开头加载：

```python
from dotenv import load_dotenv
load_dotenv()  # 加载 .env 文件
```

## 问题排查

### 问题 1: 找不到环境变量

**错误**: `ValueError: Finnhub API key is required`

**解决**:
- 检查 `.env` 文件是否存在
- 检查变量名是否正确（`FINNHUB_KEY` 或 `FINNHUB_API_KEY`）
- 确认代码中调用了 `load_dotenv()`

### 问题 2: API Key 无效

**错误**: `401 Unauthorized` 或 `403 Forbidden`

**解决**:
- 检查 API key 是否正确复制（没有多余空格）
- 检查 API key 是否过期
- 检查账户是否有足够的配额

### 问题 3: HuggingFace 模型访问被拒绝

**错误**: `OSError: Can't load tokenizer`

**解决**:
- 确认已申请访问 `meta-llama/Llama-2-7b-chat-hf` 的权限
- 确认 HF_TOKEN 已正确设置
- 等待权限批准（可能需要几小时）

## 下一步

设置好 API keys 后，可以：

1. **测试新闻获取**:
   ```bash
   cd news_fetcher
   python test_news_fetcher.py
   ```

2. **运行完整流程**:
   ```bash
   python main.py --start_date "2024-12-01" --end_date "2025-11-30"
   ```

## 总结

**推荐设置方式**:
1. 复制 `.env.example` 到 `.env`
2. 编辑 `.env` 填入你的 API keys
3. 确保 `.env` 在 `.gitignore` 中（已配置）
4. 运行代码时，环境变量会自动加载

**文件结构**:
```
Dual-Insight Trader/
├── .env.example      # 模板文件（可以提交到 Git）
├── .env              # 你的实际配置（不会提交到 Git）
└── API_KEYS_SETUP.md # 本指南
```


