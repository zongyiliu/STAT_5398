"""
Sentiment Agent - Uses Llama 3.1 Base Model (no LoRA)
Updated for Llama 3.1 support with chat template
"""

import os
import re
import torch
from transformers import AutoTokenizer, AutoModelForCausalLM
import sys
sys.path.append(os.path.dirname(os.path.dirname(os.path.abspath(__file__))))

# Try to load from .env file if available
try:
    from dotenv import load_dotenv
    load_dotenv()
except ImportError:
    pass

from news_fetcher.prompt_builder import PromptBuilder
from news_fetcher.data_fetcher import NewsDataFetcher


class SentimentAgent:
    """
    Sentiment analysis agent using Llama 3.1 Base Model (no LoRA)
    """
    
    def __init__(self, model_path=None, tokenizer_path=None, hf_token=None):
        """
        Initialize sentiment agent with Llama 3.1
        
        Args:
            model_path: Path to base model (default: 'meta-llama/Llama-3.1-8B-Instruct')
            tokenizer_path: Path to tokenizer (default: same as model_path)
            hf_token: HuggingFace token (if None, uses HF_TOKEN env var)
        """
        self.hf_token = hf_token or os.environ.get("HF_TOKEN")
        if not self.hf_token:
            raise ValueError("HuggingFace token is required. Set HF_TOKEN environment variable.")
        
        # Default to Llama 3.1-8B-Instruct
        base_model_path = model_path or 'meta-llama/Llama-3.1-8B-Instruct'
        tokenizer_path = tokenizer_path or base_model_path
        
        print(f"Loading Llama 3.1 model: {base_model_path}")
        print("Note: Using Base Model (no LoRA adapter)")
        
        self.base_model = AutoModelForCausalLM.from_pretrained(
            base_model_path,
            token=self.hf_token,
            trust_remote_code=True,
            device_map="auto",
            torch_dtype=torch.float16,
        )
        
        # Use base model directly (no LoRA)
        self.model = self.base_model
        self.model = self.model.eval()
        
        print(f"Loading tokenizer: {tokenizer_path}")
        self.tokenizer = AutoTokenizer.from_pretrained(
            tokenizer_path,
            token=self.hf_token
        )
        
        # Set pad token if not set
        if self.tokenizer.pad_token is None:
            self.tokenizer.pad_token = self.tokenizer.eos_token
        
        # Initialize prompt builder
        self.prompt_builder = PromptBuilder()
        self.data_fetcher = NewsDataFetcher()
        
        # System prompt (same as before)
        self.SYSTEM_PROMPT = (
            "You are a seasoned stock market analyst. Your task is to list the positive "
            "developments and potential concerns for companies based on relevant news and "
            "basic financials from the past weeks, then provide an analysis and prediction "
            "for the companies' stock price movement for the upcoming week. "
            "Your answer format should be as follows:\n\n"
            "[Positive Developments]:\n1. ...\n\n"
            "[Potential Concerns]:\n1. ...\n\n"
            "[Prediction & Analysis]:\nPrediction: ...\nAnalysis: ..."
        )
    
    def format_prompt(self, system_prompt, user_prompt):
        """
        Format prompt using Llama 3.1 chat template
        
        Args:
            system_prompt: System instruction
            user_prompt: User input prompt
            
        Returns:
            Formatted prompt string
        """
        messages = [
            {"role": "system", "content": system_prompt},
            {"role": "user", "content": user_prompt}
        ]
        try:
            # Use tokenizer's chat template (recommended for Llama 3.1)
            formatted = self.tokenizer.apply_chat_template(
                messages,
                tokenize=False,
                add_generation_prompt=True
            )
            return formatted
        except Exception as e:
            print(f"⚠️  Chat template not available, using manual format: {e}")
            # Fallback to manual format
            return (
                f"<|begin_of_text|><|start_header_id|>system<|end_header_id|>\n\n"
                f"{system_prompt}<|eot_id|><|start_header_id|>user<|end_header_id|>\n\n"
                f"{user_prompt}<|eot_id|><|start_header_id|>assistant<|end_header_id|>\n\n"
            )
    
    def analyze(self, news_data, symbol, date, n_weeks=3):
        """
        Analyze news sentiment and generate trading signal
        
        Args:
            news_data: DataFrame with news data (optional, if None will fetch)
            symbol: Stock ticker symbol
            date: Trading date string
            n_weeks: Number of weeks to look back
            
        Returns:
            dict: {
                'signal': 1 (buy), -1 (sell), 0 (hold),
                'confidence': 0.0-1.0,
                'positive_count': int,
                'negative_count': int,
                'predicted_return': float,
                'raw_output': str
            }
        """
        # Fetch data if not provided
        if news_data is None:
            news_data = self.data_fetcher.fetch_all_data(symbol, date, n_weeks)
        
        # Build prompt
        info, prompt = self.prompt_builder.get_all_prompts_online(
            symbol, news_data, date, with_basics=True
        )
        
        # Format prompt using Llama 3.1 chat template
        formatted_prompt = self.format_prompt(self.SYSTEM_PROMPT, prompt)
        
        # Generate prediction
        inputs = self.tokenizer(formatted_prompt, return_tensors='pt')
        inputs = {key: value.to(self.model.device) for key, value in inputs.items()}
        
        with torch.no_grad():
            res = self.model.generate(
                **inputs,
                max_length=4096,
                do_sample=True,
                eos_token_id=self.tokenizer.eos_token_id,
                pad_token_id=self.tokenizer.pad_token_id,
                use_cache=True,
                temperature=0.7,
                top_p=0.9
            )
        
        output = self.tokenizer.decode(res[0], skip_special_tokens=True)
        
        # Parse output
        result = self._parse_output(output, symbol)
        result['raw_output'] = output
        
        return result
    
    def _parse_output(self, output, symbol):
        """
        Parse FinGPT output to extract signal
        
        Args:
            output: Raw model output
            symbol: Stock ticker symbol (for context)
            
        Returns:
            dict with signal, confidence, etc.
        """
        # Extract prediction - support both single value and range formats
        # Examples: "Up by 3%", "Up by 3-4%", "Down by 2%", "Down by 2-3%"
        prediction_match = re.search(
            r'Prediction:\s*(?:up|down)\s*(?:by)?\s*([\d.]+)(?:-([\d.]+))?%',
            output,
            re.IGNORECASE
        )
        
        predicted_return = 0.0
        if prediction_match:
            if prediction_match.group(2):  # Range format (e.g., "3-4%")
                value1 = float(prediction_match.group(1))
                value2 = float(prediction_match.group(2))
                # Use average of the range
                value = (value1 + value2) / 2
            else:  # Single value format (e.g., "3%")
                value = float(prediction_match.group(1))
            
            # Check if up or down
            # Look for "up" or "down" near the prediction
            prediction_text = prediction_match.group(0).lower()
            if 'up' in prediction_text or 'increase' in output.lower():
                predicted_return = value / 100
            elif 'down' in prediction_text or 'decrease' in output.lower():
                predicted_return = -value / 100
            else:
                # Default to positive if unclear
                predicted_return = value / 100
        
        # Count positive and negative factors
        positive_matches = re.findall(r'\[Positive Developments\]:', output, re.IGNORECASE)
        concern_matches = re.findall(r'\[Potential Concerns\]:', output, re.IGNORECASE)
        
        positive_count = len(positive_matches)
        concern_count = len(concern_matches)
        
        # Generate signal based on prediction
        if predicted_return > 0.02:  # Predict > 2% increase
            signal = 1
            confidence = min(abs(predicted_return) * 10, 1.0)
        elif predicted_return < -0.02:  # Predict > 2% decrease
            signal = -1
            confidence = min(abs(predicted_return) * 10, 1.0)
        else:
            signal = 0
            confidence = 0.5
        
        return {
            'signal': signal,
            'confidence': confidence,
            'positive_count': positive_count,
            'negative_count': concern_count,
            'predicted_return': predicted_return
        }
